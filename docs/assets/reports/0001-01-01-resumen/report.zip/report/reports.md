Considering the 1d wave equation with constant coefficient
$$\begin{cases}
&u_{tt}- u_{xx} =0,  x\in \Omega, t\in[0,T] \\
& u(x,0)=u_0(x)\, \, \text{ on } \Omega, \\
& u_t(x,0)=v_0(x)\,\,\text{ on } \Omega. \\
& u(x,t)=0, \,\, \text{ on } \partial \Omega \times[0,T],
\end{cases}
\label{wave}$$ Here we set $\Omega=[-1,1]$, $T=5$.\
Variational formulation and properties of RPS basis
====================================================

Goal of RPS method is to construct a finite dimensional space $V_H$ ,
and approximate solution $u\in V$(Here, $V$ is just $H_0^2[-1,1]$) by
$u_H \in V_H$ in a certain norm, such that, $\|u-u_H\| \leq CH$.\
The weak formulation of is $$\begin{cases}
&\int_{-1}^{1}(\frac{d^2}{dt^2}u) v dx- \int_{-1}^{1}\frac{d}{dx}u \frac{d}{dx} v dx =0,  \forall v\in H_0^1[-1,1], t\in[0,T] \\
& u(x,0)=u_0(x)\, \, \text{ on } \Omega, \\
& u_t(x,0)=v_0(x)\,\,\text{ on } \Omega. \\
& u(x,t)=0, \,\, \text{ on } \partial \Omega \times[0,T],
\end{cases}
\label{weak}$$ Let $\{x_i\}_{i=1}^N$ be the uniform mesh grids of mesh
size $H$. As for this problem, the rps basis $\phi_i(x)$ corresponding
$x_i$ is defined by $$\phi_i =\left\{
\begin{aligned}
 \arg &\min_{v\in {\color{red}H_0^2[-1,1]}}  \int_{-1}^{1}(\frac{d^2}{dx^2} v)^2 dx  \\
&s.t.\  v(x_j) = \delta_{i,j},\ \ j = \{1,...,N\}, \\
\end{aligned}
\right.
\label{basis}$$

Since \$v\in  {\color{red}H_0^2[-1,1]} \$ , the hat functions is
excluded, and for any $v\in {\color{red}H_0^2[-1,1]}$, its restriction
on interval $[x_j,x_{j+1}]$ \$ v\_{I\_j}
\notin{\color{red}H_0^2[x_j,x_{j+1}]} \$

The classical hat function can also be avoided by changing the
constrains instead of energy form and solution space. $$\phi_i =\left\{
    \begin{aligned}
    \arg &\min_{v\in {\color{red}H_0^1[-1,1]}}  \int_{-1}^{1}(\frac{d}{dx} v)^2 dx  \\
    &s.t.\ \int_{-1}^{1} \frac{1}{H}v(x)\chi_{[x_j,x_j+1]} = \delta_{i,j},\ \ j = \{1,...,N-1\}, \\
    \end{aligned}
    \right.
    \label{measure}$$ where $\chi_{[x_j,x_j+1]}$ denotes the indicator
function of interval $[x_j,x_{j+1}]$.

First of all, RPS method is designed for a general operator
$-div(a\nabla\cdot)$. In the operator is specified as $\frac{d^2}{dx^2}$
as a special case. So as for the motivation in identifying the basis
through biharmonic operator. We have to start with the more general
solution space
$V:=\{v\in H_0^1(\Omega) |-div(a\nabla v)\in L^2(\Omega)\}$ for elliptic
PDEs $$\begin{cases}
    &-div \big(a(x)\nabla u\big) = g, \  \text{in}\ \Omega\\
    &u =0 \ \text{on}  \ \partial \Omega
    \end{cases}$$ The motivation in identifying the basis through
biharmonic operator lies in the fact that the unit ball of the solution
space is strongly compactly embedded into $H_0^1(\Omega)$ if source
terms $g$ are in $L^2(\Omega)$. Minimizing the
$\|-div(a\nabla v)\|_{L^2}$ energy means minimize its corresponding
source term with respect to $\|\cdot\|_{L^2}$. In Theorem \[thm\] we
will show that it gives the basis $\phi_i$ the property that
$\sum_{i=1}^{N} w_i\phi_i$ minimize the $\|-div(a\nabla w)\|_{L^2}$ over
all function $w$ such that $w(x_i)=w_i, i=1,...,N$, which means the
stability of interpolation using these basis, and the error estimate
relies on this property. The constrains give the local property of basis
functions, otherwise, minimizing $\|-div(a\nabla \cdot)\|_{L^2}$ energy
on a unit ball ($\|v\|_{L^2}=1$)gives eigenfunctions of operator
$-div(a\nabla \cdot)$, which is not practical because it’s nonlocal. The
constrains could vary from points constrain as or volume average as .

Here the energy we minimize is corresponding the second term in weak
formulation $\int_{-1}^{1}\frac{d}{dx}u \frac{d}{dx} v dx$ .
$\{x_i\}_{i=1}^N$ is the uniform mesh grids of mesh size $H$. The shape
of basis is as shown in figure \[fig1\] below. The first column is the
basis $\phi_i$ solved from and the second column describes the log scale
of $\phi_i$. It shows exponential decay property of the basis.\
\[htbp\] \[fig1\]

problem is well posed(strictly convex ) quadratic optimization problem.
There exit a unique minimizer.

Let $v\in H_0^2[-1,1]$ be a admissible element of , such that
$v(x_j) = \delta_{i,j},\ \ j = \{1,...,N\},$ and $w\in H_0^2[-1,1]$ such
that $w(x_j) = 0,\ \ j = \{1,...,N\}$. Write \$f(\lambda) =
\int*{-1}\^{1}(\frac{d^2}{dx^2} (v+\lambda w))\^2 dx \$. Next we prove
$f(\lambda)$ is strictly convex.
$$f(\lambda)= \int_{-1}^{1}(\frac{d^2}{dx^2} v)^2 dx + 2\lambda \int_{-1}^{1}(\frac{d^2}{dx^2} v) (\frac{d^2}{dx^2}w) dx +\lambda^2 \int_{-1}^{1}(\frac{d^2}{dx^2} w)^2 dx,$$
and noting that $\int_{-1}^{1}(\frac{d^2}{dx^2} w)^2 dx >0$ because if
$\int_{-1}^{1}(\frac{d^2}{dx^2} w)^2 dx =0$, given the boundary
condition of $w$, we have $w=0$. We deduce that $f(\lambda)$ is strictly
convex in $\lambda$. We conclude that ( pp. 35, Proposition
1.2[@ekeland1999convex]) is a strictly convex optimization. For a
strictly convex optimization problem, we have at most one minimizer.
Since the energy \$\int*{-1}\^{1}(\frac{d^2}{dx^2} \cdot)\^2 dx \$ is a
equivalent norm of $\|\cdot\|_{H^2}$ for $H_0^2[-1,1]$, according the
Lax-Milgram theorem, there exist a unique minimizer.

Representation of $\phi_i$
--------------------------

Let $G(x,y)$ be the Green’s function of operator
$\frac{\partial^2}{\partial x^2}$ with boundary condition, such that
$$\begin{cases}
\frac{\partial^2}{\partial x^2} G(x, y) = \delta(x-y)，\quad &x\in \Omega, \\
G(x, y) = 0  \quad &x\in \partial\Omega.
\end{cases}
\label{green}$$

For this simple case, \$G(x,y) \$ has a explicit formulation as
$$G(x,y)=\left\{
    \begin{aligned}
    -\frac{1}{2}(x+1)(y-1) \ \  x\leq y,\\
    -\frac{1}{2}(x-1)(y+1)\ \  x > y .
    \end{aligned}
    \right.
    \label{1dgreen}$$

$G(x,y)$ is symmetric. Define
$$\tau(x,y) = \int_{-1}^{1}G(x,z)G(y,z)dz,\  x,y \in [-1,1] . 
\label{tau}$$ Note that $\tau(x,y)$ is symmetric and is well defined
since $G(x,y)$ is bounded. $\tau(x,y)$ is fundamental solution of \$
\frac{d^4}{dx^4}\$ $$\begin{cases}
\frac{\partial^4}{\partial x^4} \tau(x, y) = \delta(x-y)，\quad &x\in \Omega, \\
\tau(x, y)= \frac{\partial^2}{\partial x^2} \tau(x, y)= 0  \quad &x\in \partial\Omega.
\end{cases}$$

Define $$\begin{aligned}
& V_0:=\left\{
v \in H_0^2[-1,1]\ \big|\  v(x_i) =0,\ \forall i\in{1,...,N}
\right\}.
\label{V_0} \end{aligned}$$ For $u,v \in H_0^2[-1,1]$, define the scalar
product \$&lt;\cdot,\cdot&gt;:= \int\_{-1}\^{1}\frac{d^2}{dx^2}u
\frac{d^2}{dx^2} v dx \$.

Define the $N\times N$ matrix $\Theta$ by
$$\Theta_{i,j} : = \tau(x_i,x_j).$$ then
$$\phi_i(x): = \sum_{j=1}^N \Theta_{i,j}^{-1} \tau(x,x_j)
    \label{basisrepresentation}$$ is the unique minimizer of . $\phi_i$
is orthogonal to $V_0$ with respect to product $\<\cdot,\cdot\>$.\
Further more, $\sum_{i=1}^{N} w_i\phi_i$ minimize the
$\<w,w\>= \int_{-1}^{1}(\frac{d^2}{dx^2}w)^2 dx$ over all function
$w\in H_0^2[-1,1]$ such that $w(x_i)=w_i, i=1,...,N$

Let us first prove that $\phi_i$ is a admissible element regarding the
constraints in . Observing that $\Theta_{k,j} : = \tau(x_k,x_j)$, we
deduce that
$$\phi_i(x_k)=\sum_{j=1}^N \Theta_{i,j}^{-1} \tau(x_k,x_j)=(\Theta^{-1}\Theta)_{i,k}=\delta_{i,k}, for \ k=1,...,N$$
Next, we prove that $\phi_i$ is the minimizer.

By simple integral by parts, we have
$$\<\tau(x,x_i),v\> = \int_{-1}^{1}\frac{d^2}{dx^2}\tau(x,x_i) \frac{d^2}{dx^2} v dx = 0,\ \forall v\in V_0, \ i=1,...,N.$$
Then $\phi_i(x)$, as a linear combination of
$\{\tau(x,x_i)\}_{i=1,...,N}$, satisfy that
$$\<\phi_i,v\>=\int_{-1}^{1}\frac{d^2}{dx^2}\phi_i \frac{d^2}{dx^2} v dx = 0,\ \forall v\in V_0.
    \label{variational}$$ It leads to for any $v\in V_0$,
$$\int_{-1}^{1}(\frac{d^2}{dx^2} (\phi_i+v))^2 dx=\<\phi_i+v,\phi_i+v\>=\<v,v\>+\<\phi_i,\phi_i\> \geq \int_{-1}^{1}(\frac{d^2}{dx^2} \phi_i)^2$$
We come to the conclusion .\
$\sum_{i=1}^{N} w_i\phi_i$ minimize the
$\<w,w\>= \int_{-1}^{1}(\frac{d^2}{dx^2}w)^2 dx$ over all function
$w\in H_0^2[-1,1]$ such that $w(x_i)=w_i, i=1,...,N$ is direct result
from

[@OwhZhaBer:2014] Let \$u \$ be the solution in \$H\_0\^1\[-1,1\] \$ to
\$a(u,v)=\[g,v\], \forall v\in H\_0\^1\[-1,1\] \$ Let \$u\_\phi \$ is
the unique solution in $\Phi:=\mathrm{span}\{\phi\}_{i=1}^N$ to
\$a(u\_\phi,v)=\[g,v\], \forall v\in \Phi \$ then
$$\|u-u_{\phi}\|_{H_0^1} \leq CH\|f\|_{L^2}$$ \[thm\]

$\forall v\in V_0$, it hold true that
$$\int_{-1}^{1}(\frac{d}{dx}v)^2 dx \leq CH^2 \int_{-1}^{1}(\frac{d^2}{dx^2}v)^2 dx,$$
where the constant $C$ is the constant of poincaré inequality.\
Let $u_{int}:=\sum_{i=1}^{N}u(x_i)\phi_i$. Observing that
$u-u_{int} \in V_0$ we deduce that $$\begin{aligned}
     \int_{-1}^{1}(\frac{d^2}{dx^2}(u-u_{int}))^2 dx 
     &\leq CH^2 \int_{-1}^{1}(\frac{d^2}{dx^2}(u-u_{int}))^2 dx \\
     &\leq CH^2 (\int_{-1}^{1}(\frac{d^2}{dx^2}u)^2 dx +\int_{-1}^{1}(\frac{d^2}{dx^2}u_{int})^2 dx) \\
     & \leq 2 CH^2 \|g\|^2_{L^2}
     \end{aligned}$$ The third inequality is because of
$\int_{-1}^{1}(\frac{d^2}{dx^2}u_{int})^2 dx\leq \int_{-1}^{1}(\frac{d^2}{dx^2}u)^2 dx$

In[@Owhadi2015], Bayesian homogenization approach is brought up. the
basis $\phi_i$ can be rediscovered by a Bayesian inference problem,
through the randomization of the original associated deterministic
problem as a stochastic equation,

$$\begin{cases}
    &-div \big(a(x)\nabla u\big) = \xi(x), \  \text{in}\ \Omega\\
    &u =0 \ \text{on}  \ \partial \Omega
    \end{cases}
    \label{eq:ranellp}$$

where $\xi(x)$ is set as a centered Gaussian field with covariance
$\Lambda(x,y)=\delta(x-y)$. Once $N$ observation $\{u(x_i)\}_{i=1}^N$
are given, one can find the optimal (deterministic) conditional
approximation to $u(x)$ of the following form.
$$\mathbb{E}[u|W] = \sum_{i=1}^N u(x_i) \phi_i(x)，$$ where
$W:=\{ u(x_i), \ldots, u(x_N)\}$ are the $n$
measurements/observations(these observations could be generalized to
volume average and so on), and $\phi_i(x)$ is a posterior basis
corresponding to the observation $u(x_i)$. I will show the posterior
basis is just the previous one we solve from optimization problem, that
is to say, it has the same formulation as . It means the RPS basis can
be recovered from a Bayesian point of view.\
Let $G(x,y)$ be the green function of operator $-div \big(a(x)$, such
that $$\begin{cases}
    -div \big(a(x) G(x, y) = \delta(x-y)，\quad &x\in \Omega, \\
    G(x, y) = 0,   \quad &x\in \partial\Omega,
    \end{cases}$$ then it has been proved that

[@Owhadi2015] The solution to is a Gaussian field on $\Omega$ with
covariance $\Gamma(x,y): = \mathbb{E}[u(x)u(y)]$, where
$$\begin{aligned}
        \Gamma(x,y) & = \mathbb{E}[u(x)u(y)] = \mathbb{E}[\int_{\Omega^2}G(x,z)\xi(z)G(y,z')\xi(z')dz dz']  \nonumber \\
        & = \int_{\Omega^2}G(x,z)\Lambda(z,z')G(y,z')dzdz' 
        = \int_{\Omega}G(x,z)G(y,z)dz. \label{eq:gamma}
        \end{aligned}$$ \[prop:2\]

[@Owhadi2015] Let $u(x)$ be the solution of , and
$W:=\{ u(x_i), \ldots, u(x_N)\}$ are the given observation/measurements
of $u(x)$, then $$\mathbb{E}[v(x)| W] = \sum_{i=1}^N u(x_i) \phi_i(x),
        \label{eq:condexp}$$ and
$$\phi_i(x): = \sum_{j=1}^N \Theta_{i,j}^{-1} \Gamma(x,x_i) .$$
Furthermore, $(v(x)| W )$ is a Gaussian random variable with mean , and
variance
$$\sigma(x)^2 = \Gamma(x,x) - \sum_{i,j=1}^N \Theta_{i,j}^{-1}\Gamma(x,x_i) 
        \Gamma(x,x_j).$$

### Fully Discretization

[In the above description, the optimization problem defined on
$H_0^2[-1,1]$. For numerical implementation, we need to formulate and
solve the problem in the full discrete setting. We will introduce a fine
mesh grids of mesh size $h$, $h\ll H$, by refine the original mesh
several times. The diagram \[\[fig2\]\] illustrated the construction of
fine mesh and coarse mesh in 2D case. In figure \[\[coarse\]\], the red
triangles is coarse mesh. In figure \[\[fine\]\], the blue ones is fine
mesh.]{} Let $S_h$ be the $P1$ finite element space defined on fine
mesh. Define $\phi_{i,h} \in S_h$ as a finite dimensional approximation
of $\phi_i$ by $$\phi_{i,h} =\left\{
        \begin{aligned}
        \arg &\min_{v\in S_h}  \int_{-1}^{1}(\frac{d^2}{dx^2} v)^2 dx  \\
        &s.t.\  v(x_j) = \delta_{i,j},\ \ j = \{1,...,N\}, \\
        \end{aligned}
        \right.$$

Let $\{xx_i\}_{i=1}^n$ be the fine mesh grids with mesh size $h$. Let
\$v\_h \in S\_h \$. Let $\vec{v}$ be a $n$ dimensional vector and the
$n_{th}$ component denotes the point value $v(xx_i)$. Then $v_h$ can be
represented by $v_h=\sum_{i=1}^{n}v_i h_i(x)$, where $h_i(x)$ denotes
the P1 hat function corresponding $xx_i$. $$\begin{cases}
    \min \frac{1}{2} \vec{v}^T K \vec{v} \\
     s.t.  B \vec{v}=\vec{e_i},
    \end{cases}
    \label{prob:c1}$$ where $K$ is a $n\times n$ matrix defined by
$K_{i,j}=\int_{-1}^{1}\frac{d^2}{dx^2}h_i\frac{d^2}{dx^2}h_j dx$, $B$ is
a $N \times n$ matrix, $\vec{e_i}$ is the $i-$th column of the
$N\times N$ identity matrix. $B\vec{v} =\vec{e_i}$ is the discrete
condition corresponding to \$ \phi*i(x\_j) =\delta*{i,j}\$.

This theorem guarantees a good approximation in $\Phi$. For constant
coeffcient, the result is not better then classical finite element. But
when coefficient is rough, one order of $H$ convergence rate no longer
holds true for classical finite elements .

Semi-discretization based on finite element space $\Phi$
========================================================

The semi-discretization of weak variation formulation of is
$$M \frac{d^2 \boldsymbol{u}}{dt^2}=-R\boldsymbol{u},$$ where
$M_{i,j}:=\int_{-1}^{1}\phi_i\phi_j dx$ ,
\$R\_{i,j}=\int\_{-1}\^{1}\frac{d}{dx}\phi\_i\frac{d}{dx}\phi\_j dx \$
and $\boldsymbol{u}$ is a vector with components $u_i,i=1,...,N$.\
Define the $N\times N$ symmetric positive definite matrix $\bar{R}$ by
$$\bar{R}_{i,j}=\int_{-1}^{1}\frac{d}{dx}\tau(x,x_i)\frac{d}{dx}\tau(x,x_j) dx$$
Then $$\begin{aligned}
R_{i,j=}\int_{-1}^{1}\frac{d}{dx}\phi_i\frac{d}{dx}\phi_j dx
&=\sum_{k=1}^N \sum_{q=1}^N \Theta_{i,k}^{-1}\Theta_{j,q}^{-1}\int_{-1}^{1}\frac{d}{dx}\tau(x,x_k)\frac{d}{dx}\tau(x,x_q) dx \\
&=(\Theta^{-1}\bar{R} \Theta^{-1})_{i,j} .
\end{aligned}
\label{stiff}$$

Define the $N\times N$ symmetric positive definite matrix $\bar{M}$ by
$$\bar{M}_{i,j} : = \int_{-1}^{1} \tau(x_i,x)\tau(x_j,x) dx,
\label{M}$$ then we have the mass matrix $M$ of finite element space
$\Phi$ as $$M=\Theta^{-1}\bar{M}\Theta^{-1}
\label{mass}$$ Combing and we have the semi-descretetization as
$$\Theta^{-1}\bar{M}\Theta^{-1} \frac{d^2 \boldsymbol{u}}{dt^2}=\Theta^{-1}\bar{R} \Theta^{-1}\boldsymbol{u},$$
which, since $\Theta$ is nonsingular, is equal to
$$\bar{M}\Theta^{-1} \frac{d^2 \boldsymbol{u}}{dt^2}=-\bar{R} \Theta^{-1}\boldsymbol{u},$$
Since there is no explicit formulation of $\Theta^{-1}$, I don’t know
how to carry out a Fourier analysis with a inverse of matrix. Besides,
\$\bar{M} \$ and $\bar{R}$ are not toeplitz matrix. I wish you could
give some ideas.

After careful calculation, I derive the explicit formulation of using .

$$\int_{-1}^{1} \tau(y_i,x)\tau(y_j,x) dx=\left\{
\begin{aligned}
(y_1^7*y_2)/10080 - y_1^7/10080 + (y_1^6*y_2)/1440 - y_1^6/1440 + \\ (y_1^5*y_2^3)/1440 - (y_1^5*y_2^2)/480 + (y_1^5*y_2)/720 + (y_1^4*y_2^3)/288 \\ - (y_1^4*y_2^2)/96 + y_1^4/144 + (y_1^3*y_2^5)/1440 - (y_1^3*y_2^4)/288 \\ + (y_1^3*y_2^3)/216 - (y_1^3*y_2)/540 + (y_1^2*y_2^5)/480 - \\ (y_1^2*y_2^4)/96 + (y_1^2*y_2^2)/24 - y_1^2/30 + (y_1*y_2^7)/10080 - \\ (y_1*y_2^6)/1440 + (y_1*y_2^5)/720 - (y_1*y_2^3)/540 + (y_1*y_2)/945 + \\ y_2^7/10080 - y_2^6/1440 + y_2^4/144 - y_2^2/30 + 17/630
 \ \  y_1\leq y_2,\\
\tau(y_2,y_1)\ \  y_1 > y_2 .
\end{aligned}
\right.$$

Figure \[fig:tau\]show the shape of $\tau(x,y)$ on $[-1,1]\times [-1,1]$

![the shape of $\bar{M}(x,y)$](tau "fig:"){width="40.00000%"
height="35.00000%"} \[fig:tau\]

According to the definition of $\Theta_{i,j}:=\tau(x_i,y_j)$, and the
result shown in figure \[fig:tau\], the matrix $\Theta$ is not toeplitz
matrix, which means $e^{i\xi x_{n}}$ is not its eigenvector. The martrix
$\bar{M}$ and $\bar{R}$ are also not toeplitz matrix. I know I can
bypass that difficulty by considering the system satisfied by
$\Theta^{-1} u$ if $\Theta$ is toeplitz matrix. But I am not sure if it
is not toeplitz matrix. I have referred the Symmetric Discontinuous
Galerkin Methods for 1-D Waves. But in that case, the $M$ and $R$ are
toeplitz matrix. Could you give me some reference to do discrete fourier
analysis regarding a full matrix like this. Now, I am trying to apply
periodic condition on basis, such that, the corresponding stiff and mass
matrix will be toeplitz matrix. In that way, it will be easy to
implement discrete fourier analysis.

Fourier Analysis
================

Considering the 1d wave equation with constant coefficient
$$\begin{cases}
 &u_{tt}- u_{xx} =0,  x\in \Omega, t\in[0,T] \\
 & u(x,0)=u_0(x)\, \, \text{ on } \mathbb{R}, \\
 & u_t(x,0)=v_0(x)\,\,\text{ on } \mathbb{R}. 
 \end{cases}
 \label{Cauchy}$$ The semi-discretization of weak variation formulation
of is $$M \frac{d^2 \boldsymbol{u}}{dt^2}=-R\boldsymbol{u},
 \label{semi}$$ where $M_{i,j}:=\int_{-\infty}^{+\infty}\phi_i\phi_j dx$
,
\$R\_{i,j}=\int\_{-\infty}\^{+\infty}\frac{d}{dx}\phi\_i\frac{d}{dx}\phi\_j
dx \$ and $\boldsymbol{u}$ is a vector with components
$u_i,i\in \mathbb{Z}$ and $$\phi_i =\left\{
  \begin{aligned}
  \arg &\min_{v\in {\color{red}H^2(\mathbb{R})}}  \int_{-1}^{1}(\frac{d^2}{dx^2} v)^2 dx  \\
  &s.t.\  v(x_j) = \delta_{i,j},\ \ j \in \mathbb{Z}, \\
  \end{aligned}
  \right.
  \label{cauchy_basis}$$ Since the basis defined in is globally
supported, I truncate the calculation of node $x_0=0$ on a $[-1,1]$ and
shift the basis to other nodes.\
The sinusoidal function
$$u_{\omega,n}(t) = v_{\omega} (t) e^{i\omega x_n}$$ is a solution of
provided
$$\frac{d^2}{dt^2} v_{\omega}(t) = \hat{A}(\omega) v_{\omega}(t),
   \label{v_omega}$$ where $\hat{A}(\omega)$ is defined by
$$\hat{A}(\omega)= \frac{-R e^{i\omega x_n}}{M e^{i\omega x_n} }.$$ Note
that, $\hat{A}(\omega)$ is negative. By solving , we have
$v_{\omega}(t)$ as follows
$$v_{\omega}(t) = v_{\omega}(0)e^{\pm i\omega(x+c(\omega)t)}
  \label{sinusoidal}$$ where
$c(\omega)= (-\hat{A}(\omega)/\omega^2)^{-1/2}$. Since, I don’t know the
explicit formulation of $M$ and $R$, I can only calculate the
$c(\omega)$ numerically. Figure \[velocity\] shows the results. The $x$
axis stands for $\omega H$ in range $[0,2\pi]$.

![the velocity at which the sinusoidal solution
propagate](velocity "fig:"){width="40.00000%" height="35.00000%"}
\[velocity\]

The group velocity is defined as
$$\mathbb{V}(\omega) = \frac{d}{d\omega}(c(\omega)\omega)$$

![the group velocity at which the sinusoidal solution
propagate](group_velocity "fig:"){width="40.00000%" height="35.00000%"}
\[group\_velocity\]

Figure \[group\_velocity\] shows the group velocity at which the
sinusoidal solution propagate and also the one for P1 FEM. The results
shows that although rps method also have the vanishing velocity problem
when $\omega*H=\pi$, it has better approximation then p1 element as
$\omega*H$ approaching $\pi$. The numerical results also verify this
phenomenon. The results also show that the velocity of RPS is a bit
faster then that of exact solution and this is also well explained by
figure \[group\_velocity\]. We consider 1-d wave equation
$u_{tt}=u_{xx}, \Omega=[-1,1]$. $T=5$. Initial condition is set as
follows with $\xi = \frac{5}{6}\pi$

$u(x,0)=exp(-\gamma (x)^2/2)cos(\xi x/H)$

$u_t(x,0)= u_x=-\gamma x exp(-\gamma(x)^2/2)cos(\xi x/H)-\xi/H exp(-\gamma(x)^2/2)sin(\xi x/H)$

$u(0,t)=u(1,t)=0$\
Figure \[dispersion\] shows the dispersion relation of RPS method, p1
element, and the exact one.

![dispersion relation comparision](dispersion "fig:"){width="40.00000%"
height="35.00000%"} \[dispersion\]
