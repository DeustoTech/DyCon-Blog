function plotSHE(OptState,OptControl,Yfree,YT,xline,tspan,Nt,N)

figure
subplot(2,1,1)
surf(OptState','MeshStyle','col','LineWidth',1.5)
title('Controlled Dynamics')
xlabel('space discretization')
ylabel('Time')
yticks([1 Nt])
yticklabels([tspan(1) tspan(end)])
hold on
colormap jet
plot3(1:N,ones(N,1),OptState(:,1),'ko','MarkerSize',5,'MarkerFaceColor','g')
plot3(1:N,Nt*ones(N,1),OptState(:,end),'ko','MarkerSize',5,'MarkerFaceColor','g')

%%
% The control function inside the control region
subplot(2,1,2)
surf(OptControl','EdgeColor','none')
title('Control')
xlabel('space discretization')
ylabel('Time')
yticks([1 Nt])
yticklabels([tspan(1) tspan(end)])
%%
figure;
line(xline,YT,'Color','red')
line(xline,Yfree(:,end),'Color','blue')
line(xline,OptState(:,end),'Color','green')
legend('Target','Free Dynamics','controlled dynamics')

end

