function [A,B,count] = GetABmatrix(N,w1,w2,D)

% Here we count how many elements in the discretization should be placed
% inside the control region
count=1;
for i=1:N
    if (double(i-1))/double(N) > w1
        if (i-1)/double(N) < w2
            count=count+1;
        end
    end
end


A=D*(N^2)*(full(gallery('tridiag',N,1,-2,1)));
%%
% We define the matrix B that will be the effect of the interior control to the dynamics
B = zeros(N,count);
count2=1;
for i=1:N
    if (i-1)/double(N) >= w1
        if (i-1)/double(N) < w2
            B(i,count2)=1;
            count2=count2+1;
        end
    end
end

end

