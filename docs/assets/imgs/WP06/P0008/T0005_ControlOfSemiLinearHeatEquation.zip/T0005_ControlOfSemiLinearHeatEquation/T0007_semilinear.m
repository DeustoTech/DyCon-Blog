%%
%% Semi-linear semi-discrete heat equation and collective behavior
% In this tutorial we will apply the DyCon toolbox to find a control to the
% semi-discrete semi-linear heat equation. 
%%
% $$y_t-N^2Ay=G(y)+Bu$$
%%
% where $N^2A$ is the discretization of the Laplacian in 1d in $N$ nodes.
% We are looking for a control that after time $T$ steers the system near
% zero. In order to do so we will frame the problem as a minimization of a
% functional and we will apply gradient descent to find it. Note that the
% convexity of the fuctional is not proven, therefore, we will obtain a
% local minima for the functional. The functional
% considered will be:
%%
% $$J(\boldsymbol{y},\boldsymbol{u})= | \boldsymbol{y}(t) |_{L^2}^2+\int_0^T
% | \boldsymbol{u}(t) |_{L^2}^2 dt$$
%%
% where by $\| \cdot \|_{L^2}$ we understand the discrete $L^2$ norm.
%% 
% Once this control is computed for a certain N, we will think on a dynamical
% system that models an opinion dynamics with $N$ agents communicating
% through a chain.
%%
% \begin{equation}\label{m1}y_t-\frac{1}{N}Ay=G(y)+Bv\end{equation}
%%
% The goal will be to compute also the control $v$ thinking model
% \eqref{m1} as if it was a semidiscretization of a heat equation with
% diffusivity $\frac{1}{N^3}$.
% Furthermore we will also compute the control for model \eqref{m1} with
% the non-linearity being non-homogeneous on $N$ and a time horizon being
% $T_N=N^3T$.
%%
clear all
import casadi.*
%%
% Definition of the time 
ts = SX.sym('t');
% Discretization of the space
N = 30;
xi = 0; xf = 1;
xline = linspace(xi,xf,N);
%%
% Interior Control region between 0.5 and 0.8
w1 = 0.5; w2 = 0.8; 
D = 1;
%%
[A,B,count] = GetABmatrix(N,w1,w2,D);
%%
% we define symbolically the vectors of the state and the control
%%
Ys = SX.sym('y',[N 1]);
Us = SX.sym('u',[count 1]);
%%
% We create the functional that we want to minimize
% Our goal is to set the system to zero penalizing the norm of the control
% by a parameter $\beta$ that will be small.
YT = 0*xline.';

dx = xline(2) - xline(1);
beta = dx^4;
%
%%
% We create the ODE object
% Our ODE object will have the semi-discretization of the semilinear heat equation.
% We set also initial conditions, define the non linearity and the interaction of the control to the dynamics.
%%
% Initial condition
Y0 = 2*sin(pi*xline');
%%
% Diffusion part: the discretization of the 1d Laplacian

%%
% Definition of the non-linearity
% $$ \partial_y[-5\exp(-y^2)] $$
%%
G = casadi.Function('NLT',{Ys},{10*Ys.*exp(-Ys.^2)});%  
%%
% and we define the part of the dynamics corresponding to the nonlinearity
%%
% Putting all the things together
F = casadi.Function('F',{ts,Ys,Us},{A*Ys + B*Us + G(Ys)});
% Creation of the ODE object
% Time horizon
T = 1;
%%
% We create the ODE-object and we change the resolution to $dt=0.01$ in order
% to see the variation in a small time scale. We will get the values of the
% solution in steps of size odeEqn.dt, if we do not care about
% modifying this parameter in the object, we might get the solution in
% certain time steps that will hide part of the dynamics.
%%
Nt = 30;
tspan = linspace(0,T,Nt);
ipde = semilinearpde1d(Ys,Us,A,B,G,tspan,xline);
ipde.InitialCondition = Y0;
%%
% We solve the equation and we plot the free solution applying solve to odeEqn and we plot the free solution.
%%
Yfree = solve(ipde,ZerosControl(ipde));
Yfree = full(Yfree);
%%
figure;
surf(Yfree','MeshStyle','col','LineWidth',1.5);
hold on
colormap jet
plot3(1:N,ones(N,1),Yfree(:,1),'ko','MarkerSize',5,'MarkerFaceColor','g')
plot3(1:N,Nt*ones(N,1),Yfree(:,end),'ko','MarkerSize',5,'MarkerFaceColor','g')

title('Free Dynamics')
xlabel('space discretization')
ylabel('Time')
yticks([1 Nt])
yticklabels([tspan(1) tspan(end)])

%%
% We create the object that collects the formulation of an optimal control problem  by means of the object that describes the dynamics odeEqn, the functional to minimize Jfun and the time horizon T
%%
L   = Function('L'  ,{ts,Ys,Us},{ Us.'*Us  });
Psi = Function('Psi',{Ys}      ,{ 1e6*(Ys.'*Ys) });

iocp = ocp(ipde,L,Psi);
%%
% We apply the steepest descent method to obtain a local minimum (our functional might not be convex).
U0 =ZerosControl(ipde);
[OptControl ,OptState]  = IpoptSolver(iocp,U0);

%%
plotSHE(OptState,OptControl,Yfree,YT,xline,tspan,Nt,N)
 %%
% Now we apply the same procedure for the collective
% behavior dynamics.
%%
% We will employ a function that does the algorithm explained before for
% the semilinear heat equation having the chance to set a diffusivity
% constant.
%%
% For the simulation of the model in collective behavior we will employ a
% diffusivity $D=\frac{1}{N^3}$.
%%
D = 1/(N^3);
[A,B,count] = GetABmatrix(N,w1,w2,D);
%
G = casadi.Function('NLT',{Ys},{10*Ys.*exp(-Ys.^2)});%  
%
T = 1; 
tspan = linspace(0,T,Nt);
%
ipde = semilinearpde1d(Ys,Us,A,B,G,tspan,xline);
ipde.InitialCondition = Y0;
%
iocp = ocp(ipde,L,Psi);
%%
U0 =ZerosControl(ipde);
[OptControl ,OptState]  = IpoptSolver(iocp,U0);

%%
plotSHE(OptState,OptControl,Yfree,YT,xline,tspan,Nt,N)
%%
%%
% Now we will change also the time horizon and we will incorporate a
% non-homogeneous non-linearity, we will just divide the non-linearity $G$
% by $N^3$
%%
%%
D = 1/(N^2);
[A,B,count] = GetABmatrix(N,w1,w2,D);
%
G = casadi.Function('NLT',{Ys},{10*Ys.*exp(-Ys.^2)/N^2} );%  
%
T = N^2; 
tspan = linspace(0,T,2*Nt);
%
ipde = semilinearpde1d(Ys,Us,A,B,G,tspan,xline);
ipde.InitialCondition = Y0;
%
iocp = ocp(ipde,L,Psi);
%%
U0 =ZerosControl(ipde);
[OptControl ,OptState]  = IpoptSolver(iocp,U0);
%%
plotSHE(OptState,OptControl,Yfree,YT,xline,tspan,2*Nt,N)