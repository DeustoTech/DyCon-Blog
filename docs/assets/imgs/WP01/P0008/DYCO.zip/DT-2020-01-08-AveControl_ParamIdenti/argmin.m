function [ind] = argmin(X)
%ARGMIN Summary of this function goes here
%   Detailed explanation goes here
[~,ind] = min(X);
end

