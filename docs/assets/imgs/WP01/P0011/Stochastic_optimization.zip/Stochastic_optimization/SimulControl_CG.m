%%=========================================================================
%
% CG algorithm for the simultaneous control of parameter dependent ODE
%
% Author: Umberto Biccari
% Date: 03/06/2020
%
%%=========================================================================


clc;
close all;
clear all;

%% Input data

M = 10;                   % Number of parameters in the model
nu = linspace(1,6,M);     % Parameter set

N = 4;                    % Dimension of the problem
x0 = ones(N,1);           % Initial datum (parameter-independent)
xT = zeros(N,1);          % Target

T0 = 0; T = 1;            % Time interval
Nt = 100;                 % Size of the time-mesh
tout = linspace(T0,T,Nt); 

Nmax = 1000;              % Maximum number of iterations allowed
tol = 1e-4;               % Tolerance
beta = 1e-7;              % Penalization parameter in the functional

u = zeros(Nt,1);          % Starting value for u

%% Definiton of the dynamics
% A = dynamics matrix
% B = control matrix

Am = zeros(N,N);
for i = 1:N-1
    Am(i,i+1) = 1;
end

Bm = 3*ones(N,1);

A = zeros(N,N,M);
B = zeros(N,1,M);
for j = 1:M
    Am(N,1) = -nu(j);
    A(:,:,j) = Am;
    B(:,:,j) = Bm;
end

%% Conjugate Gradient method

iter = 1;
b = zeros(Nt,1);

ErrorVec = nan*zeros(1,Nmax);  % Store the error at each iteration
tcost = zeros(1,Nmax);         % Store the cost of each iteration
Jvec = nan*zeros(1,Nmax);      % Store the functional at each iteration

tic

% Gradient initialization

for j = 1:M
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,yout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    p0 = xT - yout(end,:)';
    [tout,pout] = ode45(@(t,p) Am'*p,tout,p0); 
    b = b + pout*Bm;
end
b = b/M;
b = flipud(b);

Au = zeros(Nt,1);

for j = 1:M
    Am = A(:, :, j);
    Bm = B(:, :, j);
    [tout,zout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,0*x0);
    p0 = zout(end,:)';
    [tout,pout] = ode45(@(t,p) Am'*p,tout,p0); 
    Au = Au + pout*Bm;
end
Au = Au/M;
Au = flipud(Au);
Au = Au+beta*u;

ga = Au - b; 
g = ga;

g0L2 = integral(@(t) interp1(tout,g,t).^2,T0,T);
gaL2 = g0L2;
gL2 = g0L2;

r = -g;
rn = sqrt(integral(@(t) interp1(tout,r,t).^2,T0,T));

tcost0 = toc;

while (rn > tol && iter <= Nmax)
    
    tic
    
    w = zeros(Nt,1);
    Jmu = 0;
    
    for j = 1:M
        Am = A(:,:,j);
        Bm = B(:,:,j);
        [tout,zout] = ode45(@(t,z) Am*z + Bm*interp1(tout,r,t),tout,0*x0);
        [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
        p0 = zout(end,:)';
        [tout,pout] = ode45(@(t,p) Am'*p,tout,p0);
        w = w + pout*Bm;
        Jmu = Jmu + 0.5*(xout(end,:)'-xT)'*(xout(end,:)'-xT);
    end
    Jmu = Jmu/M;
    w = w/M;
    w = flipud(w); 
    w = w + beta*r;
    
    alpha = integral(@(t) interp1(tout,g,t).^2,T0,T)/...
        integral(@(t) interp1(tout,r,t).*interp1(tout,w,t),T0,T);
    
    % Update the control u
    
    u = u + alpha*r;
    
    % Compute and store the error
    
    ga = g;
    gaL2 = gL2;
    g = g + alpha*w;
    gL2 = integral(@(t) interp1(tout,g,t).^2,T0,T);
    gamma = gL2/gaL2;
    r = -g + gamma*r;
    rn = sqrt( integral(@(t) interp1(tout,r,t).^2,T0,T));
    ErrorVec(iter) = rn;
    
    % Update and store the functional
    
    Ju = 0.5*beta*integral(@(t) interp1(tout,u,t).^2,T0,T);
    J = Jmu + Ju;
    Jvec(iter) = J;
    
    tcost(iter) = toc;
    
    fprintf("Iteration %i - Error %g - Cost %g\n", iter,rn,J);
        
    iter = iter + 1;
end

% Total cost
Tcost = tcost0 + sum(tcost);

%% Resolution of the dynamics with the control computed

x = cell(M,1);
for j = 1:M
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    x{j} = xout;
end

%% Data saving

tolString = num2str(tol);
StringM = num2str(M);
StringN = num2str(N);
structName = strcat('data_CG_M',StringM,'N',StringN,'.mat');

if M <= 10
    data.States = x;
end
data.Control = u;
data.TimeVector = tout;
data.TotalTime = Tcost;
data.TotalIter = iter;
data.Tolerance = tol;
data.TotalParameters = M;
data.ErrorVec = ErrorVec;
data.Error = min(ErrorVec);
data.Functional = Jvec;

save(structName,'data')

%% Plots

figure(1)
color = cool(M);

subplot(2,2,1)
for j = 1:M
    plot(tout,x{j}(:,1),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,2)
for j = 1:M
    plot(tout,x{j}(:,2),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,3)
for j = 1:M
    plot(tout,x{j}(:,3),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,4)
for j = 1:M
    plot(tout,x{j}(:,4),'Color',0.7*color(j,:))
    hold on
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.9, 0.9])
