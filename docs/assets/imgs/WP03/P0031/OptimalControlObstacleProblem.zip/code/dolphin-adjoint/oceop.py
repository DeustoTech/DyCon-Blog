__author__ = "Borjan Geshkovski"

#-----------------------------------------------------#
# Optimal control solver for the classical obstacle
# problem by use of a penalization method for the
# underlying variational inequality.
#-----------------------------------------------------#

from fenics import *
from fenics_adjoint import *
from obstacles import dome

set_log_level(ERROR)	# This will only show the relevant errors and disables the "Solving problem.." quote.

def smoothmax(r, eps=1e-4):
	""" Smooth approximation of x |--> max(x, 0) """
	return conditional(gt(r, eps), r-eps/2, conditional(lt(r, 0), 0, r**2/(2*eps)))

# Square: \Omega = [-2,2]^2.
mesh = RectangleMesh(Point(-2,-2), Point(2,2), 32, 32)

# The function space for the solution and control functions
V = FunctionSpace(mesh, "P", 1)

# The functions
y = Function(V, name="State")
u = Function(V, name="Control")
w = TestFunction(V)
psi = interpolate(dome(degree=3), V)

# The regularization parameters
alpha = 1e-4

# The boundary conditions
bc = DirichletBC(V, 0.0, "on_boundary")

yd = interpolate(Expression("0.5*(cos(x[0])+cos(x[1]))", degree=3), V)

# The source term
f = Constant(-1)

# Solving the penalized problem for the state
F = inner(grad(y), grad(w))*dx - 1/alpha*inner(smoothmax(-y+psi), w)*dx - inner(f+u, w)*dx
solve(F == 0, y, bcs=bc)

# Minimizing the objective functional to find the control
delta = Constant(1e-2)
J = assemble(0.5*inner(y-yd, y-yd)*dx + delta/2*inner(u, u)*dx)		# The objective functional
m = Control(u)

Jhat = ReducedFunctional(J, m)										# Only depnds on the control
u_opt = minimize(Jhat, options={"maxiter": 30, "gtol": 1e-6, "ftol": 1e-100})

# Update the optimal state
y_opt = y.block_variable.saved_output
Control(y).update(y_opt)

# Save the results for postprocessing in ParaView
psipvd = File("elliptic/blog/psi.pvd")
ypvd = File("elliptic/blog/y_opt.pvd")
upvd = File("elliptic/blog/u_opt.pvd")
ydpvd = File("elliptic/blog/yd.pvd")
	
ypvd << y_opt
upvd << u_opt
ydpvd << yd
psipvd << psi

# Computing the violation of the constraint u >= psi
feasibility = sqrt(assemble(inner((Max(Constant(0.0), -y_opt+psi)), (Max(Constant(0.0), -y_opt+psi)))*dx))
error = sqrt(assemble(inner(y_opt - yd, y_opt - yd)*dx))