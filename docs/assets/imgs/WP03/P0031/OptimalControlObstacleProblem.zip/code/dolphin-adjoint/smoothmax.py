from fenics import *

# Needed to have a nested conditional for the symbolic C++ rep.
parameters["form_compiler"]["representation"] = "uflacs"	

def smoothmax(r, eps=1e-4):
	""" Smooth approximation of x |--> max(x, 0). 
		Got it from: M. Hintermuller and I. Kopacka. 
						"A smooth penalty approach and a
						 nonlinear multigrid algorithm for 
						 elliptic MPECs.""
						 Computational Optimization and 
						 Applications, 50(1):111-145, 2011.
	"""
	return conditional(gt(r, eps), r-eps/2, conditional(lt(r, 0), 0, r**2/(2*eps)))
