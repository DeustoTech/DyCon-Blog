__author__ = "Borjan Geshkovski"

#-----------------------------------------------------#
# A solver for the parabolic obstacle problem by use
# of a penalization method.
#-----------------------------------------------------#

from fenics import *
from math import *
from fenics_adjoint import *
from smoothmax import smoothmax
from obstacles import bump, dome1d, idata, idata2, dome, indata, dataa
import matplotlib.pyplot as plt
from mshr import *
from collections import OrderedDict
set_log_level(ERROR)

def solver(n=100, T=1, num_steps=100):
    dt = T/num_steps
    mesh = generate_mesh(Circle(Point(0, 0), 2), 25)
    #mesh = RectangleMesh(Point(-2, -2), Point(2,2), 16, 16)
    #mesh = IntervalMesh(n, -2, 2)
    Vh = FunctionSpace(mesh, "CG", 1)

    u = Function(Vh)
    w = Function(Vh)
    
    #u0 = idata(degree=2)
    #w0 = idata(degree=2)
    #u0 = dataa(degree=2)
    u0 = indata(degree=2)
    
    v = TestFunction(Vh)
    #psi = interpolate(dome1d(degree=2), Vh)
    #psi = interpolate(dome(degree=2), Vh)
    psi = Constant(0.)

    un = interpolate(u0, Vh)
    #wn = interpolate(w0, Vh)
    
    f = Constant(-1)
    #plot(wn)
    
    eps = Constant(pow(10, -8))
    F = u*v*dx + dt*dot(grad(u), grad(v))*dx - dt/eps*inner(smoothmax(-u+psi), v)*dx - un*v*dx - dt*f*v*dx
    
    #F0 = dot(w,v)*dx + dt*dot(grad(w), grad(v))*dx - dot(wn,v)*dx + dt*dot(Constant(1),v)*dx
    F1 = dot(grad(w), grad(v))*dx - 1/eps*inner(smoothmax(-w+psi), v)*dx - f*v*dx
    bc = DirichletBC(Vh, Constant(0.8), "on_boundary")
    
    #coordinates = mesh.coordinates()
    #nodal_values = u.vector().array()
    
    #s = 0.
    #levels = OrderedDict()
    #for k in range(num_steps):
    #    s+=dt
    #    levels[float(s)] = []

    t = 0

    #fig = plt.figure()
    #plot(psi, color='k', linewidth=1)
    #fig.savefig('obstacle.png')
    #plot(un, color='b', linewidth = 0.25)
    #fig.savefig('0.png')
    #plot(psi)
    #plot(un)
    vtksol = File("output/popsol.pvd")
    #vtkobs = File("output/popobs.pvd")
    vtkel = File("output/el.pvd")
    #vtkobs << psi

    for n in range(num_steps):

        t+=dt
        #plot(u, color='k', linewidth = 0.8)
        solve(F==0, u, bcs=bc)

        #levels[float(t)] = [x for x in coordinates if u(x)<= pow(10, -8)]

        #solve(F0==0, w, bcs=bc)
        #plot(u, color='b', linewidth = 0.25)
        #k=n+1
        #fig.savefig("%s.png" % k)
        #plt.clf()
        #plot(u)
        #plot(w)
        vtksol << (u, t)
        un.assign(u) 
        #wn.assign(w)
    
    #plt.show()
    #plt.show()
    #fg = plt.figure()
    #axes = plt.gca()
    #axes.set_ylim([0, 0.8])
    #plot(u, color='r', linewidth=1)
    #plot(psi, color='k', linewidth=1)
    solve(F1==0, w, bcs=bc)
    vtkel << w
    #plot(w, color='r')
    #z = num_steps+1
    #fg.savefig('%s.png' % z)
    
    # coord = []
    # for x in coordinates:
    #     coord.append(x)

	# store = []
	# coord = []
	# for x in coordinates:
	# 	coord.append(x)
	# 	if u(x) - psi(x) <= pow(10, -8):
	# 		store.append(x)


if __name__ == '__main__':

	print("Running the solver..")
	solver()
