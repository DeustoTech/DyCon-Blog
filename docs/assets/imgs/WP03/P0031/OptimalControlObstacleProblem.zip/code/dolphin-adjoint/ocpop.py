__author__ = "Borjan Geshkovski"

#-----------------------------------------------------#
# Optimal control solver for the parabolic obstacle
# problem by use of a penalization method for the
# underlying variational inequality.
#-----------------------------------------------------#

from fenics import *
from fenics_adjoint import *
from collections import OrderedDict
from obstacles import indata

parameters["form_compiler"]["representation"] = "uflacs"	 # Needed to have a nested conditional for the symbolic C++ rep.

def smoothmax(r, eps=1e-4):
	""" Smooth approximation of x |--> max(x, 0) """
	return conditional(gt(r, eps), r-eps/2, conditional(lt(r, 0), 0, r**2/(2*eps)))

# Meshing and generating function space
mesh = RectangleMesh(Point(-2,-2), Point(2,2), 8, 8)
V = FunctionSpace(mesh, "CG", 1)					# Function space

u0 = indata(degree=2)
yd = Constant(3)

# Time parameters
dt = Constant(0.1)
T = 2

# Set up the control function (it will depend on time)
ctrls = OrderedDict()
t = float(dt)
while t <= T:
	ctrls[t] = Function(V)
	t += float(dt)

def solve_parabolic(ctrls):

	u = Function(V, name="solution")
	v = TestFunction(V)
	f = Function(V, name="source")
	d = Function(V, name="data")

	psi = Constant(0)
	epsilon = Constant(pow(10, -4))

	u_n = interpolate(indata(degree=2), V)

	F = u*v*dx + dt*dot(grad(u), grad(v))*dx - dt/epsilon*dot(smoothmax(-u+psi), v)*dx - (u_n + dt*(f+Constant(-1)))*v*dx
	bc = DirichletBC(V, 0.8, "on_boundary")	

	t = float(dt)
	j = 0.5*float(dt)*assemble((u - d)**2*dx)

	vtk_sol = File("output/parabolic/state.pvd")
	#vtk_data = File("output/parabolic/data.pvd")

	while t <= T:
		f.assign(ctrls[t])

		#data.t = t
		#d.assign(interpolate(data, V))

		solve(F==0, u, bcs=bc)

		#Jtemp = assemble((u-d)**2*dx)
		#Jlist.append(Jtemp)

		if t > T - float(dt):
			weight = 0.5
		else:
			weight = 1

		j += weight*float(dt)*assemble((u - d)**2*dx)

		vtk_sol << (u, t)
		#vtk_data << (d, t)

        # Update time
		t += float(dt)

	return u, d, j

y, yd, j = solve_parabolic(ctrls)
#j = 0.5*assemble((y-yd)**2*dx)
alpha = Constant(1e-2)

# On va reformuler la partie dans la fonctionnelle
regularisation = alpha/2*sum([1/dt*(fb-fa)**2*dx for fb, fa in
     zip(list(ctrls.values())[1:], list(ctrls.values())[:-1])])

J = j + assemble(regularisation)
m = [Control(c) for c in ctrls.values()]

rf = ReducedFunctional(J, m)
opt_ctrls = minimize(rf, options={"maxiter": 5})

dico = OrderedDict()
s = float(dt)
i = 0
while s <= T:
#     print(s)
#     print(i)
     dico[s] = opt_ctrls[i]
     i+= 1
     s += float(dt)

new_u, new_d, nj = solve_parabolic(dico)

