__author__ = "Borjan Geshkovski"

from fenics import *

# class bump(Expression):
# 	def eval(self, value, x):
# 		if -3/4 <= x[0] <= -1/4 or 1/4 <= x[0] <= 3/4:
# 			value[0] = sin(-pi/2*(1-x[0])/2 + 7*pi/2*(1-(1-x[0])/2))
# 		else: 
# 			value[0] = 0

class dome1d(Expression):
	def eval(self, value, x):
		if -1<=x[0]<=1:
			value[0] = sqrt(1-x[0]*x[0])
		else:
			value[0] = 0

class indata(Expression):
	def eval(self, value, x):
		if sqrt(x[0]*x[0]+x[1]*x[1]) <= 1.95:
			value[0] = 0
		elif 1.95 <= sqrt(x[0]*x[0] + x[1]*x[1]) <= 2:
			value[0] = (sqrt(x[0]*x[0]+x[1]*x[1])-1.95)/(2-1.95)*0.8
		else:
			value[0] = 0.8

class dataa(Expression):
	def eval(self, value, x):
		if -2 <= x[0] <= -3/2:
			value[0] = -2*0.75*x[0]-3*0.75
		elif 3/2 <= x[0] <= 2:
			value[0] = 2*0.75*x[0]-3*0.75
		else:
			value[0] = 0

class idata(Expression):
	def eval(self, value, x):
		if -1<=x[0]<=1:
			value[0] = 3*sqrt(1-x[0]*x[0])
		elif -2 <= x[0] <= -3/2:
			value[0] = -2*x[0]-3
		elif 3/2 <= x[0] <=2:
			value[0] = 2*x[0]-3
		else:
			value[0] = 0

class idata2(Expression):
	def eval(self, value, x):
		if -2 <= x[0] <= -3/2:
			value[0] = -2*x[0]-3
		elif 3/2 <= x[0] <=2:
			value[0] = 2*x[0]-3
		else:
			value[0] = 0

class bump(Expression):
	def eval(self, value, x):
		if -1 <= x <= -1/2:
			value[0] = sin(-pi*x[0]-pi/2)
		elif 1/2 <= x <= 1:
			value[0] = sin(pi*x[0]-pi/2)
		else:
			value[0] = 0

class dome(Expression):
	""" Dome obstacle in [-2,2]x[-2,2] """
	def eval(self, value, x):
		if x[0]*x[0] + x[1]*x[1] < 1:
			value[0] = sqrt(1-x[0]*x[0] - x[1]*x[1])
		else:
			value[0] = 0

class stairs(Expression):
	""" Staircase obstacle in [-1,1]x[-1,1] """
	def eval(self, value, x):
		if -0.5 < x[0] <= -1:
			value[0] = -0.2
		elif -0.5 <= x[0] < 0:
			value[0] = -0.4
		elif 0 <= x[0] < 0.5:
			value[0] = -0.6
		elif 0.5 <= x[0] <= 1:
			value[0] = -0.8

class parabola(Expression):
	def eval(self, value, x):
		value[0] = -pow(x[0], 2)

class gaussian(Expression):
	""" Gaussian obstacle in [-2,2]x[-2,2] """
	def eval(self, value, x):
		a = 3
		value[0] = exp(-a*pow(x[0], 2) - a*pow(x[1], 2))
