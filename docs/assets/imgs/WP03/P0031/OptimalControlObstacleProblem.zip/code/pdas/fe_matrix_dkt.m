function S_dkt = fe_matrix_dkt(c4n,n4e)
[n4s,s4e] = sides(n4e);
nC = size(c4n,1); nS = size(n4s,1); 
D = sparse(2*(nC+nS),3*nC);
for j = 1:nC
    D(2*j-[1,0],3*j-[1,0]) = eye(2);
end
for j = 1:nS
    t_S = (c4n(n4s(j,2),:)-c4n(n4s(j,1),:))';
    ell_S = norm(t_S); t_S = t_S/ell_S;
    D(2*nC+2*j-[1,0],3*n4s(j,1)-2) = -3/(2*ell_S)*t_S;
    D(2*nC+2*j-[1,0],3*n4s(j,2)-2) = 3/(2*ell_S)*t_S;    
    D(2*nC+2*j-[1,0],3*n4s(j,1)-[1,0]) = -(3/4)*(t_S*t_S');
    D(2*nC+2*j-[1,0],3*n4s(j,2)-[1,0]) = -(3/4)*(t_S*t_S');
end
[s_p1,~,~,vol_T] = fe_matrices(c4n,n4e);
s_p2 = fe_matrix_p2(c4n,n4e,n4s,s4e,s_p1,vol_T);
S = sparse(2*(nC+nS),2*(nC+nS));
S(1:2:2*(nC+nS),1:2:2*(nC+nS)) = s_p2;
S(2:2:2*(nC+nS),2:2:2*(nC+nS)) = s_p2;
S_dkt = D'*S*D;

function [n4s,s4e] = sides(n4e)
nE = size(n4e,1); 
sides = reshape(n4e(:,[2,3,3,1,1,2])',2,[])';
[n4s,~,sideNrs] = unique(sort(sides,2),'rows','first'); 
s4e = reshape(sideNrs(1:3*nE),3,[])';
