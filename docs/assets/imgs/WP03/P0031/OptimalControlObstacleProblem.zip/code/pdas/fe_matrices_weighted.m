function [s_a,m_b] = fe_matrices_weighted(c4n,n4e,a,b)
[nC,d] = size(c4n); nE = size(n4e,1);
m_loc = (ones(d+1,d+1)+eye(d+1))/((d+1)*(d+2));
ctr = 0; ctr_max = (d+1)^2*nE; 
I = zeros(ctr_max,1); J = zeros(ctr_max,1); 
X_s_a = zeros(ctr_max,1); X_m_b = zeros(ctr_max,1);
for j = 1:nE
    X_T = [ones(1,d+1);c4n(n4e(j,:),:)'];
    grads_T = X_T\[zeros(1,d);eye(d)];
    vol_T = det(X_T)/factorial(d);
    for m = 1:d+1
        for n = 1:d+1
            ctr = ctr+1; 
            I(ctr) = n4e(j,m); J(ctr) = n4e(j,n);
            X_s_a(ctr) = vol_T*a(j)*grads_T(m,:)*grads_T(n,:)';
            X_m_b(ctr) = vol_T*b(j)*m_loc(m,n);
        end
    end
end
s_a = sparse(I,J,X_s_a,nC,nC); m_b = sparse(I,J,X_m_b,nC,nC);
