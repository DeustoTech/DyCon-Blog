function [mp_S,vol_S] = geometry_side(Z_S)
d = size(Z_S,2); 
mp_S = sum(Z_S,1)/d;
if d == 1
    vol_S = 1;
elseif d == 2
    vol_S = norm(Z_S(1,:)-Z_S(2,:));
elseif d == 3
    vol_S = norm(cross(Z_S(3,:)-Z_S(1,:),Z_S(2,:)-Z_S(1,:)),2)/2;
end
    