function s_p2 = fe_matrix_p2(c4n,n4e,n4s,s4e,s_p1,vol_T)
nC = size(c4n,1); nE = size(n4e,1); nS = size(n4s,1);
s4e = s4e+nC;
m_loc = [2,1,1;1,2,1;1,1,2]/12;
shift = [2,1]; sides = [2,3;3,1;1,2]; 
s_p2 =  sparse(nC+nS,nC+nS); s_p2(1:nC,1:nC) = s_p1;
for j = 1:nE
    grads_T = [ones(1,3);c4n(n4e(j,:),:)']\[zeros(1,2);eye(2)];
    for k = 1:3
        for ell = 1:3
            for m = 1:2
                for n = 1:2
                  s_p2(s4e(j,k),s4e(j,ell)) = ...
                    s_p2(s4e(j,k),s4e(j,ell))+16*vol_T(j)...
                    *grads_T(sides(k,m),:)...
                    *grads_T(sides(ell,n),:)'...
                    *m_loc(sides(k,shift(m)),sides(ell,shift(n)));
                end
            end
        end
    end
    for k = 1:3
        for ell = 1:3
            for n = 1:2
                 s_p2(n4e(j,k),s4e(j,ell)) = ...
                   s_p2(n4e(j,k),s4e(j,ell))+4*(vol_T(j)/3)...
                   *grads_T(k,:)*grads_T(sides(ell,n),:)';                   
            end
            s_p2(s4e(j,ell),n4e(j,k)) = s_p2(n4e(j,k),s4e(j,ell));
        end
    end    
end
