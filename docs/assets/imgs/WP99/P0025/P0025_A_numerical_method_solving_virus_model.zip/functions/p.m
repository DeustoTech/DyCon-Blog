  function y=p(t)
  to=0.5;
  if t<=to
            y=0;
        else
            y=0.3;
        end
 end