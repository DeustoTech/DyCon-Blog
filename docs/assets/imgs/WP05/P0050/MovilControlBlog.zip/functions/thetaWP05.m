function r = thetaWP05(s)
%THETAWP05 Summary of this function goes here
%   Detailed explanation goes here
k = 15;
r =  1./(1+exp(-2*k*s));

end

