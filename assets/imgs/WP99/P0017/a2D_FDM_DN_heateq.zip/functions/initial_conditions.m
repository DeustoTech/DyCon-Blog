function [U1_0, U2_0, UG_0] = initial_conditions(n)
x1 = linspace(0,1,n+2); % discretization points in x direction for subdomain 1 and also discretization points in y direction for both subdomains
x2 = linspace(1,2,n+2); % discretization points in x direction for subdomain 1
exact_u = @(x,y) (-200*sin(pi.*y.^2).*sin((pi/2).*(x.^2))); % initial condition
for i=2:length(x1)-1
    for j=2:length(x1)-1
        U1_0(i-1,j-1) = exact_u(x1(i),x1(j));
    end
end
for i=2:length(x2)-1
    for j=2:length(x1)-1
        U2_0(i-1,j-1) = exact_u(x2(i),x1(j));
    end
end
for i=2:length(x1)-1
    UG_0(i-1,1) = exact_u(x1(end),x1(i));
end
U1_0 = U1_0';
U2_0 = U2_0';
end