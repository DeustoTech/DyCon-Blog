function [A1,A2,A1g,A2g,Ag1,Ag2,Agg1,Agg2,M1,M2,M1g,M2g,Mg1,Mg2,Mgg1,Mgg2] = compute_matrices(n,lambda1,lambda2,alpha1,alpha2)

dx=1/(n+1);

main = ones(n,1);
Atil = spdiags([main -4*main main], -1:1, n, n);
Atil_G = spdiags([(1/2)*main -2*main (1/2)*main], -1:1, n, n);
I = speye(n);

A1 = (lambda1/(dx^2))*blktridiag(Atil,I,I,n);
A2 = (lambda2/(dx^2))*blktridiag(Atil,I,I,n);

M1 = alpha1*speye(n*n);
M2 = alpha2*speye(n*n);

A1g = sparse(n*n,n);
A2g = sparse(n*n,n);
A1g(end-n+1:end,:) = (lambda1/(dx^2))*I;
A2g(1:n,:) = (lambda2/(dx^2))*I;

Ag1 = sparse(n,n*n);
Ag2 = sparse(n,n*n);
Ag1(:,end-n+1:end) = (lambda1/(dx^2))*I;
Ag2(:,1:n) = (lambda2/(dx^2))*I;

Agg1 = (lambda1/(dx^2))*Atil_G;
Agg2 = (lambda2/(dx^2))*Atil_G;

M1g = sparse(n*n,n);
M2g = sparse(n*n,n);

Mg1 = sparse(n,n*n);
Mg2 = sparse(n,n*n);

Mgg1 = (alpha1/2)*I;
Mgg2 = (alpha2/2)*I;

end