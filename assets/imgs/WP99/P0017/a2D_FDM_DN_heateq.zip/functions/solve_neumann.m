function [U2_new,UG_new] = solve_neumann(n,dt,U1_0,U2_0,UG_0,A,M,Ag2,Mg2,A2g,M2g,Agg1,Agg2,Mgg1,Mgg2,Ag1,Mg1,U1,UG_old)

u1 = reshape(U1,[n*n,1]);
u1_0 = reshape(U1_0,[n*n,1]);
u2_0 = reshape(U2_0,[n*n,1]);

B = sparse(n*n+n,n*n+n);
B(1:n*n,1:n*n) = M - dt*A;
B(end-n+1:end,1:n*n) = Mg2 - dt*Ag2;
B(1:n*n,end-n+1:end) = M2g - dt*A2g;
B(end-n+1:end,end-n+1:end) = Mgg2 - dt*Agg2;

b = sparse(n*n+n,1);
b(1:n*n) = M*u2_0 + M2g*UG_0;
b(end-n+1:end) = -(Mg1 - dt*Ag1)*u1 - (Mgg1 - dt*Agg1)*UG_old + Mg1*u1_0 + Mg2*u2_0 + (Mgg1+Mgg2)*UG_0;

u = B\b; % solve equation (5)
u2_new = u(1:n*n);
UG_new = u(end-n+1:end);
U2_new = reshape(u2_new,[n,n]);
end