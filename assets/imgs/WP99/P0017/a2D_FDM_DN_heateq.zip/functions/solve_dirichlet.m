
function [U] = solve_dirichlet(n,dt,U0,UG_0,A,M,Ag,Mg,UG_old)

u0 = reshape(U0,[n*n,1]);

u = (M-dt*A)\(M*u0 + Mg*UG_0 - (Mg - dt*Ag)*UG_old); % solve equation (4)
U = reshape(u,[n,n]);
end