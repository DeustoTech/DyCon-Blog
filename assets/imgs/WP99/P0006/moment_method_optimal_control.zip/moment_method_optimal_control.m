%% OBJECTIVE OF THE NOTE
% The aim of this note is to explain how one can solve an optimal control
% problem with the moment method. While the theory is collected in [1],
% we will explain how one is able to use the Globtipoly toolbox, which is
% a powerful toolbox able to solve many other problems. This toolbox is
% available in http://homepages.laas.fr/henrion/software/gloptipoly3/. 
% A more detailed documentation is provided in this link, if you are
% insterested in other applications than the optimal control problem. 
%%
% The use of this toolbox needs a proper installation either of Sedumi or
% the Mosek solvers, which are toolboxes instrumental to solve
% numerically SDP (Semidefinite Program) problems, i.e. optimization
% problems expressed with LMI (Linear Matrix Inequalities) constraints.
%%
% This note does not aim at explaining all the details of the toolbox
% Globtipoly, since there exists already the paper [2] which introduces
% really well the problem. It does not aim neither at introducing in
% details the moment framework developed by Jean Bernard Lasserre and
% Didier Henrion, which is much more general than the optimal control
% problem framework. In this note, we just give a simple example to explain
% how this method can be used in the context of optimal control (especially
% for ODEs). Thanks to the recent paper [3], we also think that this
% framework might also work for optimal control of PDEs. 

%% FRAMEWORK
% We focus on the following ordinary differential equations:
%%
% $$
% \begin{cases}
%    \dot{x} = f(x,u) \\
%    x(0)=x_0
% \end{cases}
% $$
%%
% where $x$ belongs to a subset $X$ of $\mathbb{R}^n$ and $u$ to a subset
% $U$ of $\mathbb{R}^m$. We assume that $f$ 
% is a polynomial of $x$ and $u$. Moreover, we assume that $X$ and $U$ can  
% be written with finitely many polynomial inequalities. The Gloptipoly
% toolbox allows to solve the following kind of optimal control problem:
%% 
% $$
% \begin{cases}
% \rho^\star = \inf_u \int_{t_0}^T l(x(t),u(t))dt + l_T(x(T))
% \\ \text{    s.t }  \dot{x} = f(x,u), x(t_0)=x_0
% \\                  x(t) \in X,\: t\in  [t_0,T]
% \\                  u(t) \in U,\: t\in [t_0,T]
% \\                  x(T) \in X_T,
% \end{cases}
% $$
%%
% where $X_T$ is also a subset of $\mathbb{R}^n$ defined with finitely many
% polynomial inequalities and $l$ is also a polynomial in the variables $x$
% and $u$. 
%% A SIMPLER EXAMPLE AS A MOTIVATION
% We focus on a specific example to make the reading of thenote easier. 
% We have
%%
% $$ 
%   x=\begin{bmatrix} x_1 & x_2\end{bmatrix}\in\mathbb{R}^2
% $$
%%
% $u\in\mathbb{R}$ and:
%%
% $$
% f(x,u):=\begin{bmatrix}
% x_1\\
% u
% \end{bmatrix}
% $$
%%
% It is a simple chain of integrators, really well-known in automatic
% control theory. As described in [1], the related system can be equivalently
% rewritten as follows:
%%
% $$
% \int_{K_2} g(x) d\mu_2(x) -g(x_0) = \int_{K_1} \frac{d}{dx}g(x) f(x,u)
% d\mu_1(x),
% $$
%%
% where $g$ is any test function in $C^1(X)$, $\mu_1(x)$ is a 
% measure supported on a compact set $K_1$ representing the constraints on
% $x$ and $u$, $\mu_2(x)=$ is supported on a 
% given compact set $K_2$ corresponding to performance
% requirements. For example $K_2 = 0$ indicates that state $x$
% must reach the origin.
%%
% The approximation provided by Gloptipoly consists in reducing 
% the class of test function $g$ to be polynomials, with maximal degree $d$. 
% This maximal degree $d$ is the parameter of approximation of the program.
% As proved in [1], the higher the degree $d$ is, the better is the result 
% of the approximation.
%%
% Our aim is to find the minimal time so that the trajectories of the
% system go to $0$. Obviously, this result is already known, but we provide
% this simple example to make clear the use of the Globtipoly toolbox
%% IMPLEMENTATION
% Before going to the optimal control problem, some (easy) technical lines
% of command are necessary for Gloptipoly to work.
%%
% First, you have to add to the path the toolbox Globtipoly
%%
%%untar('http://homepages.laas.fr/henrion/software/gloptipoly3/gloptipoly3.tar.gz')
%%addpath(genpath('gloptipoly3'))

%%
% Second, you have also to add to the path the toolbox Sedumi.
%%unzip('https://github.com/sqlp/sedumi/archive/master.zip')
%%addpath(genpath('sedumi-master'))

%%
% Then, you are ready to define the optimization problem. 
%%
x0 = [1; 1]; u0 = 0; % initial conditions
d = 6; % maximum degree of test function. 
%%
% We compute the analytic minimum time. We want to know whether we are able
% to compute the good one with the toolbox Gloptipoly.

if x0(1) >= -(x0(2)^2-2)/2
tmin = 1+x0(1)+x0(2)+x0(2)^2/2;
elseif x0(1) >= -x0(2)^2/2*sign(x0(2))
tmin = 2*sqrt(x0(1)+x0(2)^2/2)+x0(2);
else
tmin = 2*sqrt(-x0(1)+x0(2)^2/2)-x0(2);
end
%%
% We define measures for constraints. In other words, we also define the
% vector field under consideration.
%%
% The command mpol in Globtipoly allows to define the variables under
% consideration. One can then define polynomials with respect to these
% variables. 
%%
% The command meas allows to define a measure depending on several
% variables. Hence, when writing meas([x_1;u_1]), one is defining a measure
% depending on the variables x_1 and u_1.

mpol x1 2
mpol u1
m1 = meas([x1;u1]);
%%
% We now define a measure associated to $x_2$, which will be related to
% some performance requirement. Indeed, we will impose that this variable
% is dissipative. 
%%
mpol x2 2
m2 = meas(x2);
%%
% We then define the vector field.
f = [x1(2);u1];
%%
% We now define the test functions as polynomials, with maximal degree $d$.
% The command mmon in Globtipoly allows to define monomials up to an order
% $d$. 

g1 = mmon(x1,d);
g2 = mmon(x2,d);
%%
% It is also necessary to assign the initial conditions, for the
% states as well for the control. 
%%
assign([x1;u1],[x0;u0]);
g0 = double(g1);
%%
% We define $K_1$ and $K_2$. The set $K_1$ is defined as: $K_1= \lbrace
% x_1,u_1 \in \mathbb{R}^2\mid x_1(2)\geq -1,\: u_1^2\leq 1\rbrace$ and
% $K_2$ is defined as: $K_2 =\lbrace x_2\in\mathbb{R}\mid x_2^2\leq 0\rbrace$. 
%%
% We have also to define the cost function of the problem under consideration.
% The one we are considering is quite simple and just reduces to being
%% 
% $$ \int_{K_1} d\mu_1$$
%%
% In terms of functions, this means that you are minizing $x_1(t)$. This
% implies in particular that you are looking for the minimal time such that
% the trajectory $(x_1(t),x_2(t))$ will converge to $(0,0)$. 
%%
% In other words, we are asking that the mass the measure $\mu_1$ is
% minimal.
%%
% Finally, we define also the differential equation with the polynomials truncated
% up to the order $d$. The command mom corresponds to the integral of
% polynomials against the suitable measure. For instance, for mom(g_2), one
% integrates the the polynomial g_2 against the measure $\mu_2$. 

P = msdp(min(mass(m1)),... %Definition of the cost function
u1^2 <= 1,... % Definition of $K_1$
x1(2) >= -1,... % Definition of $K_&$
x2'*x2 <= 0,... % Definition of $K_2
mom(g2) - g0 == mom(diff(g1,x1)*f)); % Definition of the dynamics.
%%
% The command msdp allows to define the problem and all the constraints. As
% written in [1], this means that you are transforming the problem on
% functions into a SDP (Semi-definite programming) problem.
%%
% Once you do that, one has to solve this SDP problem. The command msol
% allows to do that.
[status,obj] = msol(P);
%%
% You display the minimal time and the lower bound of the cost
% functional. 
disp(['Minimum time = ' num2str(tmin)]);
disp(['LMI ' int2str(d) ' lower bound = ' num2str(obj)])
%%
% For the initial condition x0 = [1 1] the exact minimum time is equal to 3.5.
% In table 1 of [2], a table is provided where you can see that when increasing
% $d$ the minimum time becomes closer and closer to the analytic one. We
% copy it in the note.

%% Conclusion
% As noticed before, this note aimed at providing a quick course on how
% using the toolbox Gloptipoly toolbox to solve optimal control problem.
% The document [2] provides more examples, even for other kinds of
% optimization problem. Hence, we refer the interested reader to this
% document if he is interested in using this toolbox for other problems.
% Let us note moreover that this toolbox has been used to solve nonlinear
% hyperbolic PDEs, in the paper [3]. 


%% References
% [1] J. B. Lasserre, D. Henrion, C. Prieur, and E. Trélat,  
% Nonlinear optimal control via occupation measures and LMI-relaxations, 
% SIAM J. Control Opt., vol. 47, 4, pp. 1643-1666, 2008.
%
% [2] D. Henrion, J.B. Lasserre and J. Löfberg.
% GloptiPoly 3: moments, optimization and semidefinite programming. 
% Optimization Methods & Software, 24(4-5), 761-779, 2009.
%
% [3] S. Marx, T. Weisser, D. Henrion and J.B. Lasserre.
% A moment approach for entropy solutions to nonlinear hyperbolic PDEs
% arXiv preprint arXiv:1807.02306