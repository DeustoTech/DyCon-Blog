%%% For (tau, beta, K,lambda), this function compute a lower estimate of
%%% rho.
%%% For Theorems 2.1 and 2.2.
%%% It also plots the function Gstar.

function [rho,Gstar,r0] = rho_final(t0,tau,beta,K,lambda,mu,fmax,d,d0,S_t_beta,p)
%%% Discretization of the time integral in Lambda(t0,r)
n_t = 200;

%%% Discretization of the interval [r0,1+beta]. We use monotonicity
%%% properties to compute a lower estimate of Gstar in each subinterval.
nr = 5000;

cp = (p+1)^(p+1)/p^p;

mu0 = pi^2/(4*cp);
T = 1/((p+1)*(mu-mu0));


A0 = sqrt((p*(1+K)+(p*(p+2)-K)*K)/(p*(1+K)^2));
A1 = atan(sqrt(p*(1+K)/(p*(p+2)-K)+K));
A2 = atan(sqrt(p/(p*(p+2)-K)));
A3 = atan(1/sqrt(K*beta^2*mu));
delta1 = A1/(A0*sqrt(K*mu));
delta2 = (A3-A2)/sqrt(K*mu);

r0 = 1-delta1-delta2;
r1 = 1-delta2;
    
alpha = (p+1)/((1+K)*A0^2);
    
D11 = sqrt(1+K+p*(1+K)/(p*(p+2)-K));
D12 = sqrt(1+p/(p*(p+2)-K));
D2 = (1+1/(K*mu*beta^2))^((p+1)/2);
D1 = D2*D11^alpha/D12^(p+1);
    
a1 = @(x) D1*cos(A0*sqrt(K*mu)*(x-r0)).^alpha;
a2 = @(x) D2*cos(sqrt(K*mu)*(x-1)+A3).^(p+1);
a3 = @(x) (1-(x-1)/beta).^(p+1);
    
a = @(x) (x<r0) + (x>=r0).*(x<r1).*a1(x) + (x>=r1).*(x<1).*a2(x) + (x>=1).*(x<=1+beta).*a3(x);
        
r_step = (1+beta-r0)/nr;
r_mesh = r0:r_step:1+beta-r_step;


Gstar = 10;

u_tilde = @(x) lambda*mu/fmax + (1-lambda*mu/fmax)/cosh(sqrt(cp*fmax)*(x-1-d));
W = @(x) (x<=1+d)*(K*tau+tau^(-p)) + (x>1+d)*(K*(1-(1-tau)*u_tilde(x)) + (1-(1-tau)*u_tilde(x))^(-p));

%%% The vector to plot G
Gstarr= [];

for rj = r_mesh
    
    %%% Numerator and denominator are both decrasing with r.
    %%% rjis the lower limit of each subinterval, and rj1 the upper limit.
    rj1 = rj+r_step;
    
    Lambda = Lambda_est(t0,rj1,n_t,mu,d0,p);
    num1 = 1 + p*mu*S_t_beta*Lambda;
    num2 = erf((rj1+1)/sqrt(4*t0)) + erf((1-rj1)/sqrt(4*t0));
    Gstar = min(Gstar, num1*num2/(W(rj)*a(rj)));
    Gstarr = [Gstarr,num1*num2/(W(rj)*a(rj))];
end


%%% We do not plot the 1000 last points since G becomes too big
plot(r_mesh(1:nr-1000), Gstarr(1:nr-1000))

%%% Vertical lines in the plot
h0 = vline(r0,':','r_0')
h1 = vline(r1,':','r_1')
h2 = vline(1+d,':','1+d')


rho = min([0.5*((beta-d)/beta)^(p+1)*S_t_beta*Gstar, tau^(p+1)/((p+1)*(T-t0)*mu), lambda]);


