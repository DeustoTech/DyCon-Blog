%%%%%% TABLE OF EXAMPLES SECTION 6 for Theorem 2.1 and 2.2 %%%%
clear
p=2;

mu0 = p^p*pi^2/(4*(p+1)^(p+1));

%%% Each vector contains the values [mu; fmax; d; d_0] for each example.

v1 = [1;1.1;0.1;5];
v2 = [1.25;1.3;0.1;3];
v3 = [2;2.25;0.1;4];
v4 = [2;2.25;0.05;4];
v5 = [3;3.5;0.01;5];
v6 = [4;4.1;0.05;5];
v7 = [4;4.1;0.01;5];
v8 = [4;7;0.01;5];
v9 = [6;6.2;0.01;10];
v10 = [10;10;0.005;10];

V = [v1,v2,v3,v4,v5,v6,v7,v8,v9,v10];


%V=v10;


B=[];

for v=V
    [tauopt,betaopt,Kopt,lambda_opt,rho_explored] = explore(v(1),v(2),v(3),v(4),p);
    
    t0 = (1-tauopt^(p+1))/((p+1)*v(2));
    T = 1/((p+1)*(v(1)-mu0));
    S_t_beta = exp(-pi^2*t0/(4*(v(4)+1)^2))*(1-exp(-v(4)*(v(4)-betaopt)/t0));
    
    [rho,Gstar] = rho_final(t0,tauopt,betaopt,Kopt,lambda_opt,v(1),v(2),v(3),v(4),S_t_beta,p);
    rho2 = tauopt^(p+1)/((p+1)*(T-t0)*v(1));
    B = [B;[v(1),v(2),v(3),v(4),tauopt,betaopt,Kopt,Gstar,S_t_beta,rho2, lambda_opt,rho_explored,rho_explored-rho,rho]];
end

B