%%% Numerical approximation of Lambda using the Simpson method and a
%%% discretization of the time interval in n_t subintervals.
%%% In each subinterval, we evaluate Lambda at the initial and final
%%% points, and at the midpoint.
%%% For Theorems 2.1 and 2.2
function Lambda = Lambda_Simpson(t,r,n_t,mu,d0,p)

a=-p/(p+1)-1;

S_t_0 = exp(-pi^2*t/(4*(d0+1)^2)).*(1-exp(-d0^2./t));

Y = @(x) 0.5*(p+1)*mu*S_t_0 * erf(1/sqrt(x)).*x;

tmin = 0.0001*t;
tmax = 0.9999*t;
t_step = (tmax-tmin)/n_t;
t_mesh = tmin+t_step:t_step:tmax;

Lambda = 0;



%%%%Lambda en t0
tj = tmin;


Lambda1 = 0.5*(1-Y(tj))^a * (erf((r+1)/(2*sqrt(t-tj)))+erf((1-r)/(2*sqrt(t-tj))));


for tj = t_mesh
    
    tj12 = tj-t_step/2;
    
    Lambda2 = 0.5*(1-Y(tj12))^a * (erf((r+1)/(2*sqrt(t-tj12)))+erf((1-r)/(2*sqrt(t-tj12))));
    
    Lambda3 = 0.5*(1-Y(tj))^a * (erf((r+1)/(2*sqrt(t-tj)))+erf((1-r)/(2*sqrt(t-tj))));
    
    Lambda = Lambda + t_step*(Lambda1 + 4*Lambda2 + Lambda3)/6;
    
    Lambda1 = Lambda3;
    
end
