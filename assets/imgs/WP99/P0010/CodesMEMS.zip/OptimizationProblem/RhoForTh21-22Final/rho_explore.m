%%% For (tau, beta, K) fixed, this function compute a numerical approximation of rho and lambda by
%%% iterating lambda, from an unattainable initial value for rho and
%%% decreasing it.
%%% We also input rho_opt so that we stop the iteration process of lambda if it is
%%% smaller than rho_opt obtained in previous explorations for prevoius
%%% parameters (tau, beta, K).
%%% n_t is the number of subintervals for the numerical time integral to
%%% compute Lambda(t0,r).
%%% nr is the number of points where we evaluate the function G in each
%%% subinterval [r0,r1], [r1,1] and [1,1+beta].
%%% For Theorems 2.1 and 2.2.

function [rho,lambda] = rho_explore(t0,tau,beta,K,mu,fmax,d,d0,S_t_beta,p,rho_opt,n_t,nr)

%%% Initial lambda. We have to increase this value for p>2 in order to
%%% reach values for rho bigger than 0.3.

lambda = 0.3;

cp = (p+1)^(p+1)/p^p;

mu0 = pi^2/(4*cp);
T = 1/((p+1)*(mu-mu0));

rho = 0;

A0 = sqrt((p*(1+K)+(p*(p+2)-K)*K)/(p*(1+K)^2));
A1 = atan(sqrt(p*(1+K)/(p*(p+2)-K)+K));
A2 = atan(sqrt(p/(p*(p+2)-K)));
A3 = atan(1/sqrt(K*beta^2*mu));
delta1 = A1/(A0*sqrt(K*mu));
delta2 = (A3-A2)/sqrt(K*mu);

%%% We first check if the condition delta1 + delta2 > 1 is satisfied
if delta1 + delta2 > 1
    rho = 0;
else
    
    r0 = 1-delta1-delta2;
    r1 = 1-delta2;
    
    
    %%% Since Lambda(r) does not depend on lambda, we compute it first in
    %%% the three subintervals and stock it in vectors that we will use
    %%% later.
    
    r_int = r0:(r1-r0)/nr:r1;
    Lambda_r_int = [];
    for r = r_int
        Lambda_r_int = [Lambda_r_int, Lambda_Simpson(t0,r,n_t,mu,d0,p)];
    end
    
    r_mid = r1:(1-r1)/nr:1;
    Lambda_r_mid = [];
    for r = r_mid
        Lambda_r_mid = [Lambda_r_mid, Lambda_Simpson(t0,r,n_t,mu,d0,p)];
    end
    
    
    
    r_ext = 1:beta/nr:1+beta;
    Lambda_r_ext = [];
    for r = r_ext
        Lambda_r_ext = [Lambda_r_ext, Lambda_Simpson(t0,r,n_t,mu,d0,p)];
    end
    
    
    alpha = (p+1)/((1+K)*A0^2);
    
    D11 = sqrt(1+K+p*(1+K)/(p*(p+2)-K));
    D12 = sqrt(1+p/(p*(p+2)-K));
    D2 = (1+1/(K*mu*beta^2))^((p+1)/2);
    D1 = D2*D11^alpha/D12^(p+1);
    
    a1 = @(x) D1*cos(A0*sqrt(K*mu)*(x-r0)).^alpha;
    a2 = @(x) D2*cos(sqrt(K*mu)*(x-1)+A3)^(p+1);
    a3 = @(x) (1-(x-1)/beta).^(p+1);
        
    
    %%% G does not depend on lambda in the interval [0,1], so we first
    %%% compute Gint, the minimum of G in [0,1].
    
    Gint = 10;
    j = 1;
    
    for rj = r_int
        num1 = 1+p*mu*S_t_beta*Lambda_r_int(j);
        num2 = erf((rj+1)/sqrt(4*t0))+erf((1-rj)/sqrt(4*t0));
        Gint = min( Gint, num1*num2/((K*tau + tau^(-p))*a1(rj)));
        j = j+1;
    end
    
    j = 1;
    
    for rj = r_mid
        num1 = 1+p*mu*S_t_beta*Lambda_r_mid(j);
        num2 = erf((rj+1)/sqrt(4*t0))+erf((1-rj)/sqrt(4*t0));
        Gint = min( Gint, num1*num2/((K*tau + tau^(-p))*a2(rj)));
        j = j+1;
    end
    
    %%% We iterate lambda. For each lambda, we compute G in the interval
    %%% [1,1+beta] and retain the minimum of this and Gint.
    
    while rho < lambda && lambda > rho_opt
        G = Gint;
        u_tilde = @(x) lambda*mu/fmax + (1-lambda*mu/fmax)/cosh(sqrt(cp*fmax)*(x-1-d));
        W = @(x) (x<=1+d).*(K*tau + tau^(-p)) +(x>1+d).*(K*(1-(1-tau)*u_tilde(x)) + (1-(1-tau)*u_tilde(x))^(-p));
        j=1;
        for rj = r_ext
            num1 = 1+p*mu*S_t_beta*Lambda_r_ext(j);
            num2 = erf((rj+1)/sqrt(4*t0))+erf((1-rj)/sqrt(4*t0));
            G = min(G, num1*num2/(W(rj)*a3(rj)));
            j=j+1;
        end
        
        rho = min([0.5*((beta-d)/beta)^(p+1)*S_t_beta*G,tau^(p+1)/((p+1)*(T-t0)*mu),lambda]);
        
        lambda = lambda - 0.01;
    end
    %%% We add 0.01 since we have substracted it at the end of the bucle. 
    lambda = lambda + 0.01;
end