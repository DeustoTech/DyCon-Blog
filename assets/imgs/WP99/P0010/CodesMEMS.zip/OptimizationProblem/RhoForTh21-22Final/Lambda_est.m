%%% Lower estimate of Lambda using the rectangles rule with a
%%% discretization of the time interval in n_t subintervals. We use the
%%% monotonicity properties of each term.
%%% For Theorems 2.1 and 2.2
function Lambda = Lambda_est(t,r,n_t,mu,d0,p)

a=-p/(p+1)-1;

S_t_0 = exp(-pi^2*t/(4*(d0+1)^2)).*(1-exp(-d0^2./t));

Y = @(x) 0.5*(p+1)*mu*S_t_0 * erf(1/sqrt(x)).*x;

%%% We cut the integral in order to avoid singularities
tmin = 0.0001*t;
tmax = 0.9999*t;
t_step = (tmax-tmin)/n_t;
t_mesh = tmin:t_step:tmax-t_step;

Lambda = 0;

for tj = t_mesh
    
    %%% The second term in L is decreasing with s when r>1, and increasing
    %%% else.
    tj1 = tj + t_step*(r>1);
    
    L = erf((r+1)/(2*sqrt(t-tj))) + erf((1-r)./(2*sqrt(t-tj1)));
    
    
    Lambda = Lambda + 0.5*t_step*(1-Y(tj))^a*L.*(L>0);
    
end
