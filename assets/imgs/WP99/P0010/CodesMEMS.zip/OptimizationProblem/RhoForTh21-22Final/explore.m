%%% Exploration processes for Theorems 2.1 and 2.2
function [tauopt,betaopt,Kopt,lambda_opt,rho_opt] = explore(mu,fmax,d,d0,p)

rho_opt = 1e-6;

%%% First exploration %%%

tau_step = 1/10;
tau_list = 0.1:tau_step:1;

for tau = tau_list
    t0 = (1-tau^(p+1))/((p+1)*fmax);
    beta = d+0.1;
    while beta < d0 && beta < 2
        S_t_beta = exp(-pi^2*t0/(4*(d0+1)^2))*(1-exp(-d0*(d0-beta)/t0));
        K = 0.1;
        while K <= min(p*(p+2)/(p*mu*beta^2+1),p)
            %%% The condition delta1+delta2 < 1 is checked in the
            %%% function rho_explore.
            [rho,lambda] = rho_explore(t0,tau,beta,K,mu,fmax,d,d0,S_t_beta,p,rho_opt,10,20);
            if rho>rho_opt
                rho_opt = rho;
                Kopt = K;
                betaopt = beta;
                tauopt = tau;
                lambda_opt = lambda;
            end
            K = K + 0.1;
        end
        beta = beta + 0.1;
    end 
end

%%%%% Second exploration %%%%%

%%% We iterate beta around the optimal value obtained in the first
%%% exploration.

beta0 = max(betaopt - 0.1,d);
beta1 = min(betaopt + 0.1,d0);
beta_step = (beta1-beta0)/10;

%%% The upper limit of the exploration interval for K is 0.1 close to the
%%% optimal value obtained in the first exploration and smaller than p.

K1 = min(Kopt + 0.1,p);

%%% We iterate tau around the optimal value obtained in the first
%%% exploration

tau0 = max(tauopt - tau_step,0.1);
tau1 = min(tauopt + tau_step,1);
tau_step = (tau1-tau0)/10;

for tau = tau0:tau_step:tau1
    t0 = (1-tau^(p+1))/((p+1)*fmax);
    for beta = beta0:beta_step:beta1
        S_t_beta = exp(-pi^2*t0/(4*(d0+1)^2))*(1-exp(-d0*(d0-beta)/t0));
        %%% We make sure that the upper limit of the interval for K
        %%% satisfies the restriction.
        K11 = min(K1,p*(p+2)/(p*mu*beta^2+1));
        %%% We iterate K in a interval of length 0.2 since the value
        %%% obtained in the first exploration is 0.1 close to the real
        %%% optimum.
        K10 = max(K11-0.2,0.1);
        K_step = (K11-K10)/10;
        for K = K10:K_step:K11
            %%% The condition delta1+delta2 < 1 is checked in the
            %%% function rho_explore.
            [rho,lambda] = rho_explore(t0,tau,beta,K,mu,fmax,d,d0,S_t_beta,p,rho_opt,10,20);
            if rho>rho_opt
                rho_opt = rho;
                Kopt = K;
                betaopt = beta;
                tauopt = tau;
                lambda_opt = lambda;
            end
        end
    end 
end





