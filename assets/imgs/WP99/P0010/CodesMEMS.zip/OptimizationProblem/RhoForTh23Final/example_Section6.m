%%%%%% TABLE OF EXAMPLES SECTION 6 for Theorems 2.3 %%%%
clear
p=2;

mu0 = p^p*pi^2/(4*(p+1)^(p+1));

%%% Each vector contains the values [mu; fmax; d; d_0] for each example.

v1 = [0.7;0.8;0.01;8];
v2 = [0.6;0.65;0.05;10];
v3 = [0.5;0.6;0.001;6];
v4 = [0.5;0.5;0.01;7];

V = [v1,v2,v3,v4];


B=[];
error = [];

for v=V
    [tau,beta,K,eta] = explore(v(1),v(2),v(3),v(4),p);
    t = (1-tau^(p+1))/((p+1)*v(2));
    T = 1/((p+1)*(v(1)-mu0));
    [H,errorH] =  H_low_est(t,beta,50000,1,p);
    [Gt0,errorGt0] = G_low_est(t,v(1),beta,K,eta,2000,1,p);
    [GT,errorGT] = G_low_est(T,v(1),beta,K,eta,2000,1,p);
    St0 = exp(-4*pi^2*t/(v(4)+1)^2)*(1-exp(-v(4)*(v(4)-beta)/t));
    ST = exp(-4*pi^2*T/(v(4)+1)^2)*(1-exp(-v(4)^2/T));
    rho1 = 0.5*((beta-v(3))/beta)^(p+1)*min(ST*GT/(K+eta^(-p)) , St0*min(H,Gt0)/(K+tau^(-p)));
    rho2 = tau^(p+1)/((p+1)*(T-t)*v(1));
    rho = min(rho1 , rho2);
    B = [B;[v(1),v(2),v(3),v(4),tau,eta,beta,K,GT,H,Gt0,ST,St0,rho2,rho]];
    error = [error;[v(1),v(2),v(3),v(4),errorGt0,errorH,errorGT]];
end

B
error