%%%%%% TABLE OF EXAMPLES SECTION 6 for Theorems 1.1 and 1.2 %%%%
clear
p=2;

mu1 = p^p*pi^2/(2*(p+1)^(p+1));

%%% Each vector contains the values [mu; fmax; d; d_0] for each example.

v1 = [1;1.1;0.1;5];
v2 = [1.25;1.3;0.1;3];
v3 = [2;2.25;0.1;4];
v4 = [2;2.25;0.05;4];
v5 = [3;3.5;0.01;5];
v6 = [4;4.1;0.05;5];
v7 = [4;4.1;0.01;5];
v8 = [4;7;0.01;5];
v9 = [6;6.2;0.01;10];
v10 = [10;10;0.005;10];

V = [v1,v2,v3,v4,v5,v6,v7,v8,v9,v10];

%V = [v10];

B=[];

for v=V
    [tau,beta,K] = explore(v(1),v(2),v(3),v(4),p);
    t = (1-tau^(p+1))/((p+1)*v(2));
    [H,errorH] =  H_low_est(t,beta,50000,1,p);
    [G,errorG] = G_low_est(t,v(1),beta,K,2000,1,p);
    St0 = exp(-4*pi^2*t/(v(4)+1)^2)*(1-exp(-v(4)*(v(4)-beta)/t));
    rho = 0.5*((beta-v(3))/beta)^(p+1)*St0*min(H,G)/(K+tau^(-p));
    B = [B;[v(1),v(2),v(3),v(4),tau,beta,K,H,errorH,G,errorG,St0,rho]]; 
end

B