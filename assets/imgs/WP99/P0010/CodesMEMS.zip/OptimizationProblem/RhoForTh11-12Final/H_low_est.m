%%% Computes a numerical approximation or a lower estimate of H for
%%% Theorems 1.1 and 1.2.
function [H,errorH] = H_low_est(t,beta,n,lower,p)
%%% lower = 1 for a lower estimate of H and G. 
%%% lower != 1 for an approximation.

errorH = 1;

numH = @(x) erf((1+beta*x/2)./sqrt(t))-erf(beta*x./(2*sqrt(t)));
denH = @(x) (1-x).^(p+1);

if lower == 1
    % Let's divide the interval [0,1] in n intervals. 
    % x1 is the final point of each interval.
    % x2 is the initial point of each interval.
    x2 = 0:1/n:1-1/n;
    % numH and denH are both decreasing in [0,1]
    H = 10;
    for x = x2
        x1 = x + 1/n;
        Hx = numH(x1)/denH(x);
        if Hx < H
            H = Hx;
            errorH = (numH(x)-numH(x1))/denH(x);
        end
    end
else
    x = 0:1/n:1;
    H = min(numH(x)./denH(x));
end