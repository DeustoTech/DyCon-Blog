%%% Computes a numerical approximation or a lower estimate of G for
%%% Theorems 1.1 and 1.2.

function [G,errorG] = G_low_est(t,mu,beta,K,n,lower,p)
%%% lower = 1 for a lower estimate of H and G. 
%%% lower != 1 for an approximation.

errorG = 1;

L = 1+(p+1)*K;
Gamma = sqrt((p+1)*L/(p*K*mu*beta^2));
A = atan(Gamma);
alpha = 1+ p/L;
delta = A*(1+K)*sqrt((p+1)/(p*L*K*mu));

numG = @(x) erf((1-delta*(1-x)/2)/sqrt(t))+erf((1-x)*delta/(2*sqrt(t)));
denG = @(x) (cos(A*x)).^(alpha);

if lower == 1
    % Let's divide the interval [0,1] in n intervals. 
    % x1 is the final point of each interval.
    % x2 is the initial point of each interval.
    x2 = 0:1/n:1-1/n;
    % numG and denG are both decreasing in [0,1]
    G = 10;
    for x = x2
        x1 = x + 1/n;
        Gx = (Gamma^2+1)^(-alpha/2)*numG(x1)/denG(x);
        if Gx < G
            G = Gx;
            errorG = (Gamma^2+1)^(-alpha/2)*(numG(x) - numG(x1))./denG(x);
        end
    end
else
    x = 0:1/n:1;
    G = (Gamma^2+1)^(-alpha/2)*min(numG(x)./denG(x));
end