%%% Exploration processes for Theorems 1.1 and 1.2
function [tauopt,betaopt,Kopt,rho_opt] = explore(mu,fmax,d,d0,p)

rho_opt = 0;
mu1 = p^p*pi^2/(4*(p+1)^(p+1));
tau0 = mu/(2*mu-mu1);


%%% First exploration %%%

tau_step = (1-tau0)/10;
tau_list = tau0:tau_step:1;

stop_beta0 = 0;
stop_beta1 = 0;

beta_list = min(1+d,(d0+d)/2);


while stop_beta0*stop_beta1 == 0
    for beta = beta_list
        t0 = @(x) (1-x.^(p+1))/((p+1)*fmax);
        H_tau =  @(x) H_low_est(t0(x),beta,20,0,p); 
        K = max(p/(mu*beta^2)-1/(p+1),0);
        stop_K1 = 0;
        while stop_K1 == 0
            L = 1+(p+1)*K;
            Gamma = sqrt((p+1)*L/(p*K*mu*beta^2));
            A = atan(Gamma);
            delta = A*(1+K)*sqrt((p+1)/(p*L*K*mu));
            if delta<=1
                for tau = tau_list
                    t = t0(tau);
                    H = H_tau(tau);
                    St0 = exp(-4*pi^2*t/(d0+1)^2)*(1-exp(-d0*(d0-beta)/t));
                    G = G_low_est(t,mu,beta,K,20,0,p);
                    rho = 0.5*((beta-d)/beta)^(p+1)*St0*min(H,G)/(K+tau^(-p));
                    if rho>rho_opt
                        rho_opt = rho;
                        Kopt = K;
                        betaopt = beta;
                        tauopt = tau;
                    end
                end
            end
            if K > 0.5/rho_opt - 1
                stop_K1 = 1;
            else
                K=K+0.1;
            end
        end
       
    end
    if min(beta_list) <= d/(1-(2*rho_opt)^(1/(p+1))) || min(beta_list)-0.1 < d
        stop_beta0 =1;
    end
    %%% Extra stopping condition for beta
    %%% We can just use the stopping condition beta > d0.
    H_list = [];
    for tau = tau_list
        H_list = [H_list,H_tau(tau)];
    end
    if 0.5*max(H_list) <= rho_opt || beta+0.1 > d0
        stop_beta1 = 1;
    end
    if stop_beta0 + stop_beta1 == 0
        beta_list = [min(beta_list)-0.1, max(beta_list)+0.1];
    elseif stop_beta0 == 0
        beta_list = min(beta_list)-0.1;
    elseif stop_beta1 == 0
        beta_list = max(beta_list)+0.1;
    end
end


%%% Second exploration %%%

%%% We iterate beta around the optimal value obtained in the first
%%% exploration

beta0 = max(betaopt - 0.1,d);
beta1 = min(betaopt + 0.1,d0);
beta_step = (beta1-beta0)/10;

%%% The lower limit of the exploration interval for K is 0.1 close to the
%%% optimal value obtained in the first exploration.

K0 = Kopt - 0.1;


%%% We iterate tau around the optimal value obtained in the first
%%% exploration

tau0 = max(tauopt - tau_step,tau0);
tau1 = min(tauopt + tau_step,1);
tau_step = (tau1-tau0)/10;

for beta = beta0:beta_step:beta1
    t0 = @(x) (1-x.^(p+1))/((p+1)*fmax);
    H_tau =  @(x) H_low_est(t0(x),beta,20,0,p); 
    Kmin = max(p/(mu*beta^2)-1/(p+1),0);
    %%% We make sure that the initial K satisfies the restriction.
    K00 = max(Kmin,K0);
    %%% We explore K in a interval of length 0.2 since we are 0.1 colse to
    %%% the real optimal value.
    K11 = K00+0.2;
    K_step = (K11-K00)/10;
    for K = K00:K_step:K11
        L = 1+(p+1)*K;
        Gamma = sqrt((p+1)*L/(p*K*mu*beta^2));
        A = atan(Gamma);
        delta = A*(1+K)*sqrt((p+1)/(p*L*K*mu));
        if delta<=1
            for tau = tau0:tau_step:tau1
                t = t0(tau);
                H = H_tau(tau);
                St0 = exp(-4*pi^2*t/(d0+1)^2)*(1-exp(-d0*(d0-beta)/t));
                G = G_low_est(t,mu,beta,K,20,0,p);
                rho = 0.5*((beta-d)/beta)^(p+1)*St0*min(H,G)/(K+tau^(-p));
                if rho>rho_opt
                    rho_opt = rho;
                    Kopt = K;
                    betaopt = beta;
                    tauopt = tau;
                end
            end
        end
    end
end
    
