function U = CrankNicolson2DRad(U0,f,dr,dt)
  %%% U0 es el valor de la solucion en t = t_i - dt, es un vector de tama�o I
  %%% I es numero de puntos en el interior de [0,R[
  %%% f es un vector de tama�o I. 
  lambda=dt/(2*dr^2);
  I = length(f);
  
  r = 0;
  
  c=[-2*lambda];
  b=[1 + 2*lambda + 0.5*f(1)*dt/(1-U0(1))^3];
  a=[-2*lambda];
  d=[2*lambda*U0(2) + (1-2*lambda)*U0(1) + 0.5*f(1)*dt*(2-U0(1))/(1-U0(1))^3];
  
  for i = 2:I-1
    r = r+dr;
    ci = -lambda*(1+0.5*dr/r);
    c = [c,ci];
    bi = 1 + 2*lambda + 0.5*f(i)*dt/(1-U0(i))^3;
    b = [b,bi];
    ai = -lambda*(1-0.5*dr/r);
    a = [a,ai];
    di = lambda*(1+0.5*dr/r)*U0(i+1) + (1-2*lambda)*U0(i) + lambda*(1-0.5*dr/r)*U0(i-1) + 0.5*f(i)*dt*(2-U0(i))/(1-U0(i))^3;
    d = [d,di];
  end
  
  r = r+dr;
  a = [a,-lambda*(1+0.5*dr/r)];
  b = [b,1 + 2*lambda + 0.5*f(I)*dt/(1-U0(I))^3];
  c = [c,-lambda*(1-0.5*dr/r)];
  d = [d,(1-2*lambda)*U0(I) + lambda*(1-0.5*dr/r)*U0(I-1) + 0.5*f(I)*dt*(2-U0(I))/(1-U0(I))^3];
  
  c_star = [c(1)/b(1)];
  d_star = [d(1)/b(1)];
  
  for i = 2:I
    ci = c(i)/(b(i)-a(i)*c_star(i-1));
    c_star = [c_star,ci];
    di = (d(i)-a(i)*d_star(i-1))/(b(i)-a(i)*c_star(i-1));
    d_star = [d_star,di];
  end
  
  U = [d_star(I)];
  for i = 1:I-1
    Ui = d_star(I-i) - c_star(I-i)*U(1);
    U = [Ui,U];
  end
end
