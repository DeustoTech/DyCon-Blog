function finalProfile(R,I,itemax)
  
  %F = @(x) 0.42 + 1.58*(x>=-2)*(x<=0);
  F = @(x) 0.42 + 1.58*(x>=-1)*(x<=1) + 1.58*(x>=4)*(x<=6);
  
  dx = 2*R/(I+1);
   
  f=[];
  U0=[];
  x=-R;
  
  for i = 1:I
    x = x + dx;
    fi = F(x); %% function f
    f = [f,fi];
    Ui = 0; %% initial datum
    U0 = [U0,Ui];
  end
    
  Y = [0,U0,0]';
  K = 10e-3;
  Umin = min(1-U0);
  dt = K*Umin^3;
  ite = 0;
  T=0;
  Tlist=T;
  while dt > 1e-16 && ite<itemax
    U = CrankNicolson(U0,f,dx,dt);
    T=T+dt;
    Tlist = [Tlist,T];
    U0 = U;
    Umin = min(1-U0);
    dt = K*Umin^3;
    Y = [Y,[0,U0,0]'];
    ite = ite+1;
  end
  
  Ufinal = [0,U0,0];
  %plot(-R:dx:R,Y)
  
  X = -R:dx:R;
  Nframes = 200;
  qTlist = 0:T/(Nframes-1):T;
  Vq = interp1(Tlist',Y',qTlist);
  
  %plot(X,Vq)
  
  plot(X,Vq(80,:))
  
  for k=1:Nframes
      A = plot(X,Vq(k,:));
      axis([-R,R,0,1])
      saveas(A,['v6frame' num2str(k) '.png'])
  end

end
