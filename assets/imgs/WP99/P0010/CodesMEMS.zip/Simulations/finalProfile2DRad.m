function finalProfile2DRad(R,I,itemax)
  
  %F = @(r) 8*(1-0.5*(r<0.25));
  %F = @(r) 8*(1-0.75*(r<0.65)-0.75*(r>0.75));
  
  %F = @(r) 8-(0.25-r^2)^2;
  F = @(r) 8 + 0.25*r^2;
  
  dr = R/I;  
  f=[];
  U0=[];
  r=0;
  
  for i = 1:I
    fi = F(r); %% function f
    f = [f,fi];
    Ui = 0; %% initial datum
    U0 = [U0,Ui];
    r = r + dr;
  end

  Y = [U0,0]';
  K = 10e-3;
  Umin = min(1-U0);
  dt = K*Umin^3;
  ite = 0;
  T=0;
  Tlist=T;
  while dt > 1e-16 && ite<itemax
    U = CrankNicolson2DRad(U0,f,dr,dt);
    T=T+dt;
    Tlist = [Tlist,T];
    U0 = U;
    Umin = min(1-U0);
    dt = K*Umin^3;
    Y = [Y,[U0,0]'];
    ite = ite+1;
  end
  
  Ufinal = [U0,0];
  
 
  r=[0:dr:R];
  Nframes = 200;
  qTlist = 0:T/(Nframes-1):T;
  Vq = interp1(Tlist',Y',qTlist);
  
  theta = [0:2*pi/I:2*pi];
  [R,THETA] = meshgrid(r,theta);
  
  U3d = repmat(Vq(3,:),I+1,1);
  surf(R.*cos(THETA),R.*sin(THETA),U3d)
  %plot(r,Ufinal)
  
  for k=1:Nframes
      U3d = repmat(Vq(k,:),I+1,1);
      A = surf(R.*cos(THETA),R.*sin(THETA),U3d);
      axis([-1,1,-1,1,0,1])
      shading interp
      saveas(A,['v4frame' num2str(k) '.png'])
  end
end
