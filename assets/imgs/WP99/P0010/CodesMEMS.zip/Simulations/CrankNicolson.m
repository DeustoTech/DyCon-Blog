function U = CrankNicolson(U0,f,dx,dt)
  %%% U0 es el valor de la solucion en t = t_i - dt, es un vector de tama�o I
  %%% I es numero de puntos en el interior de [-R,R]
  %%% f es un vector de tama�o I. 
  r=dt/(2*dx^2);
  I = length(f);
  
  b=[1 + 2*r + 0.5*f(1)*dt/(1-U0(1))^3];
  d=[r*U0(2) + (1-2*r)*U0(1) + 0.5*f(1)*dt*(2-U0(1))/(1-U0(1))^3];
  
  for i = 2:I-1
    bi = 1 + 2*r + 0.5*f(i)*dt/(1-U0(i))^3;
    b = [b,bi];
    di = r*U0(i+1) + (1-2*r)*U0(i) + r*U0(i-1) + 0.5*f(i)*dt*(2-U0(i))/(1-U0(i))^3;
    d = [d,di];
  end
  
  b = [b,1 + 2*r + 0.5*f(I)*dt/(1-U0(I))^3];
  d = [d,(1-2*r)*U0(I) + r*U0(I-1) + 0.5*f(I)*dt*(2-U0(I))/(1-U0(I))^3];
  
  c_star = [-r/b(1)];
  d_star = [d(1)/b(1)];
  
  for i = 2:I
    ci = -r/(b(i)+c_star(i-1)*r);
    c_star = [c_star,ci];
    di = (d(i)+d_star(i-1)*r)/(b(i)+c_star(i-1)*r);
    d_star = [d_star,di];
  end
  
  U = [d_star(I)];
  for i = 1:I-1
    Ui = d_star(I-i) - c_star(I-i)*U(1);
    U = [Ui,U];
  end
end
