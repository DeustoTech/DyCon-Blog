function [y] = interval(x,a,b)

y = (x>=a).*(x<=b);

end