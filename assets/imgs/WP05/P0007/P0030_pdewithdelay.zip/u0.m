function zz=u0(x,t)    
H=@(x1,x2,x3,f1,f2)   f1+(f2-f1)*(((x1-x2).^2)*(3*x3-x2-2*x1))/((x3-x2).^3);
L=1;
point1=L/2; point2=L/2+0.1;
z1=0.2; z2=0;
    if (x <=point1 )          
       zz=z1;  
    elseif (x<=point2)
        zz=H(x,point1,point2,z1,z2) ;
    else
        zz=z2;
    end
end