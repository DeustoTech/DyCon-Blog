%%
% In this tutoral, we will demonstrate how to design a LQR controller in
% order to stabilize the linear population dynamics model dependent on age  
% and space
%%
% $$
%\begin{cases}
% y_t=y_{xx}-y_a-\mu(a)y+ \chi_{Q_{omega}\text{ in } (0,1)\times (0,A)\times (0,T)\\
%y(x,a,0)=y_0(x,a) \text { in } (0,1)\times (0,A)\\
%y(0,a,t)=y(1,a,t)=0\text{ in } (0,A)\times(0,T)\\
%y(x,0,t)=\int_{0}^{A}\beta(a)y(x,a,t)da\\
%\end{cases}
% $$
%%
% We need to reduce the PDE to the finite dimensional system of the form
%$$\dot{Z}=AZ+Bu$$
% Construction of the matrix A.
clear, close all
m=1;
n=18*m;
h=5/n;

%Matrix birth. 
% Here we control over all space and age. 

A1=eye(n);
A2=zeros(n*n,n*n);
for j=2*m:16*m
    bj=(7*(j*h-5/18)^4*exp(-(j*h-5/18)))/(gamma(5));
    A2(1:n,(j-1)*n+1:j*n)=bj*A1;
end
P=0.75*A2;
% Matrix aproximations of the second derivative in space and 
% derivative in age.
A3=diag(ones(n*n-n,1),-n);
B1=h*A3;
A4=(-2/(n*n)-h)*eye(n);
A5=diag(ones(n-1,1),1);
A6=diag(ones(n-1,1),-1);
B2=A4+(1/(n*n))*A5+(1/(n*n))*A6;
B2(1,n)=1/n;
B2(n,1)=1/n;
B3=kron(eye(n),B2);
%Mortality matrix
% We suppose that the mortality $\mu(a)=1/10$ in $(0,A/3)$,
% $\mu(a)=1/50$ in $(A/3,2A/3)$ and $\mu(a)=1/2(A-a)$
S=zeros(n*n,n*n);  
for j=1:n
    for i=1:n
        S((j-1)*n+i,(j-1)*n+i)=-1/(10*(5-(h*n*j)/(n+0.1)));
    end
end
A=B1+B3+S;
% solution  of the system without the control.
% Initial condition
T=30;
Z0=zeros(n*n,1);
for i=1:n
    for j=1:n
        Z0((i-1)*n+j,1)=exp(-(3*(i*h-3/2)^2+100*(j/n-4/10)^2));
    end
end
% a=@(x) x^2;
% [t1,Z]=ode45(@(t,Z) A*Z+arrayfun(@(x)a(x),P*Z),[0 T],Z0);
% % %%
% % %Z = Zspan;
%  L=Z(30,:);
% v=Z(60,:);
%  W=Z(105,:);
%  J=reshape(L,n,n);
%  o=reshape(v,n,n);
%  Y=reshape(W,n,n);
%  F1=reshape(Z0,n,n);
% V1=linspace(0,10,n+2);
%  V2=linspace(0,1,n+2);
%  l1=V1(1,2:n+1);
%  l2=V2(1,2:n+1);
%  [V3,V4]=meshgrid(l1,l2);
% figure;
%  surf(V3,V4,F1);
% xlabel('age');
%  ylabel('space');
%  title('initial condition');
%  figure;
%  surf(V3,V4,J);
%  xlabel('age');
% ylabel('space');
%  title('state y of the system uncontrolled at timte t=1');
% figure;
%  surf(V3,V4,o);
%  xlabel('age');
% ylabel('space');
%  title('state y of the uncontrolled system at time t=5');
% figure;
%  surf(V3,V4,Y);
% xlabel('age');
% ylabel('space');
% title('state y of the uncontrolled system at final time T=12');
% The control matrix B is constructed as follows:
V=zeros(n,1);
for l=1:12*m
    V(l,1)=1;
end
C=diag(V);
K=kron(eye(12*m),C);
B=zeros(n*n,n*n);
B(1:12*m*n,1:12*m*n)=K;
%Optimisation problem
opti = casadi.Opti();  % CasADi function
Nt = 120;
da=zeros(n*n,1);
dt=zeros(Nt,1);
for i=1:Nt
dt(i,1)=T/Nt;
end
for i=1:n*n
    da(i,1)=4/(n*n);
end
X = opti.variable(n*n,Nt+1); % state trajectory
U = opti.variable(n*n,Nt);
f_2=@(Z,U) A*Z+P*Z+B*U;
for k=1:Nt % loop over control intervals
   % Euler forward method
   x_next = X(:,k) + (T/Nt)*f_2(X(:,k),U(:,k)); 
   opti.subject_to(X(:,k+1)==x_next); % close the gaps
end
opti.subject_to(X(:,1)==Z0);
YT = zeros(n*n,1);
Cost =2*(X(:,Nt+1)-YT)'*(X(:,Nt+1)-YT)+(da'*(U.^2))*dt;
opti.minimize(Cost);
opti.solver('ipopt'); % set numerical backend
tic
sol = opti.solve();   % actual solve
toc;
q=sol.value(X);
r=sol.value(U);
Z2=reshape(r,n,n,Nt);
Z3=reshape(q,n,n,Nt+1);
V1=linspace(0,10,n+2);
V2=linspace(0,1,n+2);
l1=V1(1,2:n+1);
l2=V2(1,2:n+1);
[V3,V4]=meshgrid(l1,l2);
% figure;
% surf(V3,V4,Z2(:,:,10));
% xlabel('age');
% ylabel('space');
% title('The control state V at time t=1.2');
% figure;
% surf(V3,V4,Z2(:,:,82));
% xlabel('age');
% ylabel('space');
% title('The control state at time t=6');
% figure;
% surf(V3,V4,Z2(:,:,end));
% xlabel('age');
% ylabel('space');
% title('The control state at final time T=12');
% figure;
% surf(V3,V4,Z3(:,:,end));
% xlabel('age');
% ylabel('space');
% title('The controlled state y at final time T=12');
% figure
% figure;
% for i=1:Nt
% figg=surf(V3,V4,Z2(:,:,i));
% zlim([-0.13,0.05]);
% shading interp;
% saveas(gcf,['figg' num2str(i) '.png']);
% end
figure;
for i=1:Nt
fig=surf(V3,V4,Z2(:,:,i));
zlim([-0.05,1]);
xlabel('age');
ylabel('space');
shading interp;
saveas(gcf,['fig' num2str(i) '.png']);
end
figure;
for i=1:Nt+1
figg=surf(V3,V4,Z3(:,:,i));
zlim([-0.05,1]);
xlabel('age');
ylabel('space');
shading interp;
saveas(gcf,['figg' num2str(i) '.png']);
end
