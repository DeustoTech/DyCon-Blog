%%
% In this tutoral, we will demonstrate how to design a LQR controller in
% order to stabilize the linear population dynamics model dependent on age  
% and space
%%
% $$
%\begin{cases}
% y_t=y_{xx}-y_a-\mu(a)y+ \chi_{Q_{omega}\text{ in } (0,1)\times (0,A)\times (0,T)\\
%y(x,a,0)=y_0(x,a) \text { in } (0,1)\times (0,A)\\
%y(0,a,t)=y(1,a,t)=0\text{ in } (0,A)\times(0,T)\\
%y(x,0,t)=\int_{0}^{A}\beta(a)y(x,a,t)da\\
%\end{cases}
% $$
%%
% We need to reduce the PDE to the finite dimensional system of the form
%$$\dot{Z}=AZ+Bu$$
% Construction of the matrix A.
clc; clear;
m=1;
n=18*m;
h=5/n;

%Matrix birth. 
% Here we control over all space and age. 

A1=eye(n);
A2=zeros(n*n,n*n);
for j=m:17*m
    bj=(7*(j*h-5/18)^4*exp(-(j*h-5/18))/(gamma(5)));
    A2(1:n,(j-1)*n+1:j*n)=bj*A1;
end
P=A2;
% Matrix aproximations of the second derivative in space and 
% derivative in age.
A3=diag(ones(n*n-n,1),-n);
B1=h*A3;
A4=(-2/(n*n)-h)*eye(n);
A5=diag(ones(n-1,1),1);
A6=diag(ones(n-1,1),-1);
B2=A4+(1/(n*n))*A5+(1/(n*n))*A6;
B2(1,n)=1/n;
B2(n,1)=1/n;
B3=kron(eye(n),B2);
%Mortality matrix
% We suppose that the mortality $\mu(a)=1/10$ in $(0,A/3)$,
% $\mu(a)=1/50$ in $(A/3,2A/3)$ and $\mu(a)=1/2(A-a)$
S=zeros(n*n,n*n);  
for j=1:n
    for i=1:n
        S((j-1)*n+i,(j-1)*n+i)=-1/(10*(5-(h*n*j)/(n+0.1)));
    end
end
A=B1+B3+S;
% solution  of the system without the control.
% Initial condition
T=30;
Z0=zeros(n*n,1);
for i=1:n
    for j=1:n
        Z0((i-1)*n+j,1)=exp(-(3*(i*h-3/2)^2+100*(j/n-4/10)^2));
    end
end
a=@(x) x*exp(-x);
[t1,Z]=ode45(@(t,Z) A*Z+arrayfun(@(x)a(x),P*Z),[0 T],Z0);
%%
%Z = Zspan;
u1=Z(188,:);
L=Z(376,:);
U=Z(250,:);
W=Z(421,:);
u2=reshape(u1,n,n);
J=reshape(L,n,n);
X=reshape(U,n,n);
Y=reshape(W,n,n);
F1=reshape(Z0,n,n);
V1=linspace(0,10,n+2);
V2=linspace(0,1,n+2);
l1=V1(1,2:n+1);
l2=V2(1,2:n+1);
[V3,V4]=meshgrid(l1,l2);
zlim([0,2.5]);
figure;
surf(V3,V4,F1);
shading interp;
xlabel('age');
ylabel('space');
title('initial condition');
figure;
surf(V3,V4,u2);
shading interp;
xlabel('age');
ylabel('space');
title('state y of the system uncontrolled at timte t=10');
figure;
surf(V3,V4,J);
shading interp;
xlabel('age');
ylabel('space');
title('state y of the system uncontrolled at timte t=20');
figure;
surf(V3,V4,X);
shading interp;
xlabel('age');
ylabel('space');
title('state y of the uncontrolled system at time t=30');
figure;
surf(V3,V4,Y);
shading interp;
xlabel('age');
ylabel('space');
title('state y of the uncontrolled system at time T=40');
for i=1:144
    fig=surf(V3,V4,reshape(Z(3*i,:),n,n));
    zlim([0,2.5])
     shading interp;
    saveas(gcf,['fig' num2str(i) '.png']);
end

% The control matrix B is constructed as follows:
V=zeros(n,1);
for l=1:4*m
    V(l,1)=1;
end
% C=diag(V);
% K=kron(eye(5*m),C);
% B=zeros(n*n,n*n);
% B(1:5*m*n,1:5*m*n)=K;
% % Implementation Control
% %%
% % f_2=@(t,Z,U,Params) (A+P)*Z+B*U;
% % 
% % Zsym = sym('zsym',[n*n 1]);
% % Usym = sym('u',[n*n 1]);
% % 
% % dynEqua = ode(f_2,Zsym,Usym);
% % dynEqua.InitialCondition = Z0;
% % dynEqua.Nt = 200;
% % %%
% % [tspan,Zspan] = solve(dynEqua);
% % %%
% % 
% % 
% % Psi= @(T,Z) Z.'*Z;
% % L= @(t,Z,U) 0.005*(U.'*U);
% % iP = Pontryagin(dynEqua,Psi,L,'SymbolicCalculations',false);
% % 
% % %%
% % AMPLFile(iP,'yac.txt')
% % %%
% % U0 = zeros(200,n*n);
% % GradientMethod(iP,U0,'display','iter')
% %%
% %% Optimization problem
% opti = casadi.Opti();  % CasADi function
% 
% % ---- Input variables ---------
% Nt = 1000;
% X = opti.variable(n*n,Nt+1); % state trajectory
% U = opti.variable(n*n,Nt);   % control
% 
% f_2=@(Z,U) (A+P)*Z+B*U;
% % ---- Dynamic constraints --------
% for k=1:Nt % loop over control intervals
%    % Euler forward method
%    x_next = X(:,k) + (T/Nt)*f_2(X(:,k),U(:,k)); 
%    opti.subject_to(X(:,k+1)==x_next); % close the gaps
% end
% %
% opti.subject_to(X(:,1)==Z0);
% %opti.subject_to(X>0);
% 
% %
% YT = zeros(n*n,1);
% Cost = (X(:,Nt+1)-YT)'*(X(:,Nt+1)-YT);
% opti.minimize(Cost); % minimizing L2 at the final time
% %%
% % ---- solve NLP              ------
% opti.solver('ipopt'); % set numerical backend
% tic
% sol = opti.solve();   % actual solve
% toc
% %%
% % Numerical solution with LQ control
% [t2,Z_ctr]=ode45(f_2,[0,T],Z0);
% E=Z_ctr(750,:);
% O=Z_ctr(450,:);
% G=Z_ctr(1020,:);
% G1=reshape(G,n,n);
% N=reshape(E,n,n);
% M=reshape(O,n,n);
% figure;
% surf(V3,V4,N);
% xlabel('age');
% ylabel('space');
% title('stabilized state of the system at time t=2');
% figure;
% surf(V3,V4,M);
% xlabel('age');
% ylabel('space');
% title('stabilized state of the system at time t=5');
% figure;
% surf(V3,V4,G1);
% xlabel('age');
% ylabel('space');
% title('stabilized state of the system at time t=10')
% %%
% % 
% % <<FILENAME.PNG>>
% % 
% 
%  
% 
% 
% 
% 
