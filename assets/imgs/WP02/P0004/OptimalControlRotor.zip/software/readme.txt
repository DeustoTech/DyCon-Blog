Readme.

- "controlled.mat" MATLAB data for the spindle endpoints, in the controlled case;
- "out_rotorbalance.txt": AMPL Commands File;
- "outdata_rotorbalance.txt": AMPL output data file;
- "plotData_rotorbalance.m": MATLAB file to plot the optimal trajectories and to determine the movement of the endpoints of the spindle;
- "rotate_3D.m": MATLAB Function to compute the rotation of a vector in a 3D space;
- "RotorAnimation.m": MATLAB script to produce the animation;
- "rotorbalance.txt": AMPL model file;
- "RotorGeometry.m": MATLAB function to geometrically construct the rotor;
- "set_plot_style_v03.m": MATLAB fucntion to set options for plot;
- "uncontrolled.mat" MATLAB data for the spindle endpoints, in the uncontrolled case.