function [theta] = argument(a,b)
% We determine and return the argument of the
% the complex number z = a+ib.
%
% Input parameters.
% - a:   real part of a complex number;
% - b:   imaginary part of a complex number;
% Output parameters.
% - theta:   one of the argument of z = a+ib, namely
% a+ib = \rho \exp(i\theta)

if( a ~= 0 )
    theta = atan( b/a )+(pi/2)*sign(b)*(1-sign(a));
elseif( b>0 )
    theta = pi/2;
else
    theta = 3*pi/2;
end
end

