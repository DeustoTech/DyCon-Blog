function [Px,Py] = endpos1(Mtot,F1totx,F1toty,t)
% We determine the position of the left endpoint P of the axle.
% We work in an inertial reference frame (O;(x,y,z)).
% We assume that the P_z\equiv -a, where $a>0$.
% \begin{cases}
% \ddot{P}_x = -\frac{a1}{Mtot}*\dot{P}_x - \frac{k1}{Mtot}*{P}_x + \frac{1}{Mtot}*F1totx;\\
% P_x(0) = 0\\
% \dot{P}_x(0) = 0.\\
% \end{cases}
% \begin{cases}
% \ddot{P}_y = -\frac{a2}{Mtot}*\dot{P}_y - \frac{k2}{Mtot}*{P}_y + \frac{1}{Mtot}*F1toty;\\
% P_y(0) = 0\\
% \dot{P}_y(0) = 0.\\
% \end{cases}
% We return the solution at time t.
%
% Input parameters.
% - Mtot:  total mass of the rotor, the spindle and the balancing heads;
% - F1totx:  x_component of resulting force due to imbalance and balance exerted at P;
% - F1toty:  y_component of resulting force due to imbalance and balance exerted at P;
% - t:  time instant;
% Parametri di input/output
% - Px:   Px(t);
% - Py:   Py(t);

%% STEP 1. We define the parameters for algorithm execution.

a1 = 60;
a2 = a1;
k1 = 100;%1;
k2 = k1;
gamma1 = a1/Mtot;
omega01 = sqrt(k1/Mtot);
f1 = @(t)(1/Mtot)*F1totx(t);
gamma2 = a2/Mtot;
omega02 = sqrt(k2/Mtot);
f2 = @(t)(1/Mtot)*F1toty(t);
if ( gamma1 >= 2*omega01 )
    error('error.');
end
if ( gamma2 >= 2*omega02 )
    error('error.');
end

%% STEP 2. Conclusion.

[Px] = harmonic_oscillator(gamma1,omega01,1,1,f1,t);
[Py] = harmonic_oscillator(gamma2,omega02,1,1,f2,t);

end

