function [value] = harmonic_oscillator(gamma,omega0,x0,v0,f,t)
% We solve the Cauchy Problem (CP)
% \begin{cases}
% \ddot{x}+\gamma*\dot{x}+\omega_0^2x = f\\
% x(0) = x_0\\
% \dot{x}(0) = v_0.\\
% \end{cases}
% We return the solution at time t.
%
% Input parameters.
% - gamma:   damping coefficient, 
% WARNING: 0 < gamma^2 < 4*omega0^2;
% - omega0:   frequency undumped system, omega0 > 0;
% - x0:  initial value for the position, x0\in\mathbb{R};
% - v0:  initial value for the velocity;
% - f:   source term, f\in L^1(0,t) is a function-handle;
% - t:   time instant, where we are interested to evaluate
% the solution to (CP), t\in\mathbb{R}.

%% STEP 1. We define the parameters for algorithm execution.

Nt = 100; % Nt includes both initial and final endpoints of the time-partition.
% WARNING: Nt must be sufficiently large, in fucntion of t.
omegaD = sqrt(omega0^2-gamma^2/4);

%% STEP 2. We compute a solution to the nonhomogeneous problem,
% with intial datum (0,0).

vectint = zeros(Nt,1);
for i = 1:Nt
    ti = (i-1)*t/(Nt-1);
    vectint(i,1) = abs(f(ti)/omegaD)*exp(-(t-ti)*gamma/2)*cos(omegaD*(t-ti)-argument(0, f(ti)/omegaD));
end
int = sum(vectint)*t/(Nt-1); % solution to the nonhomogeneous problem,
% with intial datum (0,0).

%% STEP 3. Conclusion.

value = sqrt(x0^2+((2*v0+gamma*x0)/(2*omegaD))^2)*exp(-t*gamma/2)*cos(omegaD*t-argument(x0,(2*v0+gamma*x0)/(2*omegaD)))+int;
end

