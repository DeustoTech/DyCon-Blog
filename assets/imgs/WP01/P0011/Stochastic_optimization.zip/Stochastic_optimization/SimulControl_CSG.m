clc;
close all;
clear all;

%% Input data

M = 10;                    % Number of parameters in the model
Vub = 6; Vlb = 1;          % Range of the parameters
nu = linspace(Vlb,Vub,M);

Dist_Mat = abs(bsxfun(@minus,nu,nu'));

N = 4;                     % Dimension of the problem
x0 = ones(N,1);            % Initial datum (parameter-independent)
xT = zeros(N,1);           % Target

T0 = 0; T = 1;             % Time interval
Nt = 100;                  % Size of the time-mesh
tout = linspace(T0,T,Nt);

Nmax = 5000;               % Maximum number of iterations allowed
d = 1e-1;                  % Initial step-size
tol = 1.4e-4;              % Tolerance
beta = 1e-3;               % Penalization parameter in the functional

u = zeros(Nt,1);           % Starting value for u
Du = zeros(Nt,1);
random_v_values_SIG = ones(1,Nmax) + rand(Nmax,1)*(Vub - Vlb);
v = random_v_values_SIG;

%% Definition of the dynamics
% A = dynamics matrix
% B = control matrix

Am = zeros(N,N);
for i = 1:N-1
    Am(i,i+1) = 1;
end

Bm = ones(N,1);

A = zeros(N,N,M);
B = zeros(N,1,M);
for j = 1:M
    Am(N,1) = -nu(j);
    A(:,:,j) = Am;
    B(:,:,j) = Bm;
end

%% Continuous Stochastic Gradient method

error = 10;
iter = 1;

Ghistory = zeros(Nmax,Nt);     % Store the gradient at each iteration
ErrorVec = nan*zeros(1,Nmax);  % Store the error at each iteration
tcost = zeros(1,Nmax);         % Store the cost of each iteration
Jvec = nan*zeros(1,Nmax);      % Store the functional at each iteration
U_Grad = zeros(M,Nt);          % Store the gradient for each parameter
GG_norm = nan*zeros(1,Nmax);   % Store the gradient norm at each iteration

U(1,:) = u';
U_Dist = Inf*ones(1,M);


while (error > tol && iter < Nmax)
    tic
        
    j = randi(M,1);         % Select a random parameter
        
    % Compute and store the gradient corresponding to the parameter
    % selected using the adjoint methodology
    
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    p0 = -(xout(end,:)' - xT);
    [tout,pout] = ode45(@(t,p) Am'*p,tout,p0);
    pout = flipud(pout);
    Du = beta*u - pout*Bm;
    U_Grad(j,:) = Du;
    U_Dist(j) = 0;
    Ghistory(iter,:) = Du;
    
    % Compute and store the value of the functional
    
    Jmu = 0.5*(xout(end,:)' - xT)'*(xout(end,:)' - xT);
    Ju = 0.5*beta*integral(@(t) interp1(tout,u,t).^2,T0,T);
    J = Jmu + Ju;
    Jvec(iter) = J;
    
    % Compute the weights and the descent direction
    
    [~,ind] = min(bsxfun(@plus,U_Dist,Dist_Mat),[],2);
    [c,~,ind1] = unique(ind);
    a = zeros(1,M);
    for k = 1:length(c)
        a(c(k)) = sum(ind1==k);
    end
    a = a/M;
    GG = sum(diag(a)*U_Grad,1);
    GG_norm(iter) = norm(GG);
            
    % Update and sotre the control u
    
    ua = u;
    uNew = u - d*GG';
    u = uNew;
        
    U_Dist = U_Dist + norm(d*GG);
    
    % Compute and store the error
    
    U2 = integral(@(t) interp1(tout,u,t).^2,T0,T);
    Ua2 = integral(@(t) interp1(tout,ua-u,t).^2,T0,T);
    DU2 = integral(@(t) interp1(tout,Du,t).^2, T0, T);
    DUG = integral(@(t) interp1(tout,GG,t).^2, T0, T);
    error = sqrt(Ua2/U2);
    ErrorVec(iter) = error;
    
    % Update and store the functional
    
    Jmu = 0.5*(xout(end,:)' - xT)'*(xout(end,:)' - xT);
    Ju = 0.5*beta*integral(@(t) interp1(tout,u,t).^2,T0,T);
    J = Jmu + Ju;
    Jvec(iter) = J;
    
    tcost(iter) = toc;
    
    fprintf("Iteration %i - Error %g - Cost %g\n", iter,error,J);
    
    iter = iter + 1;
end

% Total cost
Tcost = sum(tcost);

%% Resolution of the dynamics with the control computed
% 
if M <= 10
    x = cell(M,1);
    for j = 1:M
        Am = A(:,:,j);
        Bm = B(:,:,j);
        [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
        x{j} = xout;
    end
end

%% Data saving

tolString = num2str(tol);
StringM = num2str(M);
StringN = num2str(N);
structName = strcat('data_CSG_fineTol_M',StringM,'N',StringN,'.mat');

if M <= 10
    data.States = x;
end
data.Control = u;
data.TimeVector = tout;
data.TotalTime = Tcost;
data.TotalIter = iter;
data.Tolerance = tol;
data.TotalParameters = M;
data.ErrorVec = ErrorVec;
data.Error = min(ErrorVec);
data.Functional = Jvec;
data.GradientNorm = GG_norm;

save(structName,'data')

%% Plots

figure(1)
color = cool(M);

subplot(2,2,1)
for j = 1:M
    plot(tout,x{j}(:,1),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,2)
for j = 1:M
    plot(tout,x{j}(:,2),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,3)
for j = 1:M
    plot(tout,x{j}(:,3),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,4)
for j = 1:M
    plot(tout,x{j}(:,4),'Color',0.7*color(j,:))
    hold on
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.9, 0.9])
