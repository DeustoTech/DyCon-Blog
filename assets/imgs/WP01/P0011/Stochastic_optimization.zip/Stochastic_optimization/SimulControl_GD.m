clc;
close all;
clear all;

%% Input data

M = 10;                   % Number of parameters in the model
nu = linspace(1,6,M);     % Parameter set

N = 4;                  % Dimension of the problem
x0 = ones(N,1);           % Initial datum (parameter-independent)
xT = zeros(N,1);          % Target

T0 = 0; T = 1;            % Time interval
Nt = 100;                 % Size of the time-mesh
tout = linspace(T0,T,Nt);

Nmax = 20000;             % Maximum number of iterations allowed
d = 1e-1;                 % Initial step-size
tol = 1e-4;               % Tolerance
beta = 1e-3;              % Penalization parameter in the functional

u = zeros(Nt,1);          % Starting value for u
Du = zeros(Nt,1);

%% Definiton of the dynamics
% A = dynamics matrix
% B = control matrix

Am = zeros(N,N);
for i = 1:N-1
    Am(i,i+1) = 1;
end

Bm = ones(N,1);

A = zeros(N,N,M);
B = zeros(N,1,M);
for j = 1:M
    Am(N,1) = -nu(j);
    A(:,:,j) = Am;
    B(:,:,j) = Bm;
end

%% Gradient Descent method

error = 10;
iter = 1;

ErrorVec = nan*zeros(1,Nmax);  % Store the error at each iteration
tcost = zeros(1,Nmax);         % Store the cost of each iteration
Jvec = nan*zeros(1,Nmax);      % Store the functional at each iteration
DuNorm = nan*zeros(1,Nmax);    % Store the gradient norm at each iteration


while (error > tol && iter < Nmax)
    tic
    
    % Compute the gradient of the functional using the adjoint methodology
    
    xAv = zeros(Nt,N);
    pM = zeros(Nt,1);
    
    for j = 1:M
        Am = A(:,:,j);
        Bm = B(:,:,j);
        [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
        p0 = -(xout(end,:)' - xT);
        [tout,pout] = ode45(@(t,p) Am'*p,tout,p0);
        pM = pM + pout*Bm;
        xAv = xAv + xout;
    end
    pM = pM/M;
    pM = flipud(pM);
    Du = beta*u - pM;
    DU2 = integral(@(t) interp1(tout,Du,t).^2, T0, T);
    DuNorm(iter) = sqrt(DU2);
    
    % Update the control u
    
    ua = u;
    u = u - d*Du;
        
    % Compute and store the error
    
    U2 = integral(@(t) interp1(tout,u,t).^2, T0, T);
    Ua2 = integral(@(t) interp1(tout,ua-u,t).^2, T0, T);
    error = sqrt(Ua2/U2);
    ErrorVec(iter) = error;
    
    % Update and store the functional
    
    Jmu = 0.5*(xAv(end,:)' - xT)'*(xAv(end,:)' - xT);
    Ju = 0.5*beta*integral(@(t) interp1(tout,u,t).^2,T0,T);
    J = Jmu + Ju;
    Jvec(iter) = J;
    
    tcost(iter) = toc;
    
    fprintf("Iteration %i - Error %g - Cost %g\n", iter,error,J);
        
    iter = iter + 1;
end

% Total cost
Tcost = sum(tcost);

%% Resolution of the dynamics with the control computed

x = cell(M,1);
for j = 1:M
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    x{j} = xout;
end

%% Data saving

tolString = num2str(tol);
StringM = num2str(M);
StringN = num2str(N);
structName = strcat('data_GD_M',StringM,'N',StringN,'.mat');

if M <= 10
    data.States = x;
end
data.Control = u;
data.TimeVector = tout;
data.TotalTime = Tcost;
data.TotalIter = iter;
data.Tolerance = tol;
data.TotalParameters = M;
data.ErrorVec = ErrorVec;
data.Error = min(ErrorVec);
data.Functional = Jvec;
data.GradientNorm = DuNorm;

save(structName,'data')

%% Plots

color = cool(M);

figure(1)
subplot(2,2,1)
for j = 1:M
    plot(tout,x{j}(:,1),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,2)
for j = 1:M
    plot(tout,x{j}(:,2),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,3)
for j = 1:M
    plot(tout,x{j}(:,3),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,4)
for j = 1:M
    plot(tout,x{j}(:,4),'Color',0.7*color(j,:))
    hold on
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.9, 0.9])
