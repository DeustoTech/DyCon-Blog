clc;
close all;
clear all;

%% Input data

M = 10;                    % Number of parameters in the model
nu = linspace(1,6,M);      % Parameter set

N = 4;                     % Dimension of the problem  
x0 = ones(N,1);            % Initial datum (parameter-independent)
xT = zeros(N,1);           % Target

T0 = 0; T = 1;             % Time interval
Nt = 100;                  % Size of the time-mesh
tout = linspace(T0,T,Nt);

Nmax = 1000000;            % Maximum number of iterations allowed
d = 1e-1;                  % Initial step-size
tol = 1e-4;                % Tolerance
beta = 1e-3;               % Penalization parameter in the functional

u = zeros(Nt,1);           % Starting value for u
Du = zeros(Nt,1);

%% Definition of the dynamics
% A = dynamics matrix
% B = control matrix

Am = zeros(N,N);
for i = 1:N-1
    Am(i,i+1) = 1;
end

Bm = ones(N,1);

A = zeros(N,N,M);
B = zeros(N,1,M);
for j = 1:M
    Am(N,1) = -nu(j);
    A(:,:,j) = Am;
    B(:,:,j) = Bm;
end

%% Stochastic Gradient Descent method

error = 10;
iter = 0;
Iter = 0;

ErrorVec = nan*zeros(1,Nmax);  % Store the error at each iteration
Jvec = nan*zeros(1,Nmax);      % Store the functional at each iteration
tcost = zeros(1,Nmax);         % Store the cost of each iteration

while (error > tol && iter < Nmax)
    tic
    iter = iter + 1;
    
    j = randi(M,1); % Select a random parameter
    
    % Compute the gradient corresponding to the parameter selected usting
    % the adjoint methodology
    
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    p0 = -(xout(end,:)' - xT);
    [tout,pout] = ode45(@(t,p) Am'*p,tout,p0); 
    
    % Update the control u
    
    ua = u;
    pout = flipud(pout);
    Du = beta*u - pout*Bm;
    u = u - d*Du;
    
    % Compute and sotre the error
    
    DU2 = integral(@(t) interp1(tout,Du,t).^2, T0, T);
    U2 = integral(@(t) interp1(tout,u,t).^2, T0, T);
    Ua2 = integral(@(t) interp1(tout,ua-u,t).^2, T0, T);
        
    error = sqrt(Ua2/U2);
    ErrorVec(iter) = error;
    
    % Update and store the functional

    Jmu = 0.5*(xout(end,:)' - xT)'*(xout(end,:)' - xT);
    Ju = 0.5*beta*integral(@(t) interp1(tout,u,t).^2,T0,T);

    J = Jmu + Ju;
    Jvec(iter) = J;
    
    % Update the step-size
    
    Jstar = 2;
    cont = abs(sum(Jvec(1:iter))-Jstar)/(iter-Iter);
    if cont < d
        d = 0.5*d;
        Iter = iter;
    end
  
    tcost(iter) = toc;
    
    if mod(iter,10) == 1
        fprintf("Iteration %i - Error %g - Cost %g\n", iter,error,J);
    end
end

% Total cost
Tcost = sum(tcost);

%% Resolution of the dynamics with the control computed

x = cell(M,1);
for j = 1:M
    Am = A(:,:,j);
    Bm = B(:,:,j);
    [tout,xout] = ode45(@(t,z) Am*z + Bm*interp1(tout,u,t),tout,x0);
    x{j} = xout;
end

%% Data saving

StringM = num2str(M);
StringN = num2str(N);
structName = strcat('data_SGD_fineTol_M',StringM,'N',StringN,'.mat');

if M <= 10
    data.States = x;
end
data.Control = u;
data.TimeVector = tout;
data.TotalTime = Tcost;
data.TotalIter = iter;
data.Tolerance = tol;
data.TotalParameters = M;
data.ErrorVec = ErrorVec;
data.Error = min(ErrorVec);
data.Functional = Jvec;

save(structName,'data')

%% Plots

figure(1)
color = cool(M);

subplot(2,2,1)
for j = 1:M
    plot(tout,x{j}(:,1),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,2)
for j = 1:M
    plot(tout,x{j}(:,2),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,3)
for j = 1:M
    plot(tout,x{j}(:,3),'Color',0.7*color(j,:))
    hold on
end

subplot(2,2,4)
for j = 1:M
    plot(tout,x{j}(:,4),'Color',0.7*color(j,:))
    hold on
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.9, 0.9])
