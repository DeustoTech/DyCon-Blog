%%=========================================================================
%
% GD-RBM algorithm for the synchronization of coupled oscillators 
%
% Author: Umberto Biccari
% Date: 03/06/2020
%
%%=========================================================================

clear all
clc

%% Input data

n = 5;                         % Number of batches
P = 2;                         % Size of each batch
N = n*P;                       % Total number of oscillators

T0 = 0; T = 3;                 % Time interval
Nt = 100;
tspan = linspace(T0,T,Nt);
dt = tspan(2)-tspan(1);

theta0vec = linspace(0,pi,N);  % Initial datum
theta0 = normpdf(theta0vec);
maxiter = 6000;                % Maximum number of iterations allowed
beta = 1e-7;                   % Penalization parameter in the functional
tol = 1e-4;                    % Tolerance
eta = 10;                      % Lenghstep for GD
u = ones(Nt,1);                % Initial control

%% Construction of the symbolic model

syms t;                      % Time variable
symU  = sym('u',[1,1]);      % Control   

symTh = sym('theta',[N,1]);  % Direct variable
symP = sym('p',[N,1]);       % Adjoint variable
symOm = sym('om',[N,1]);     % Natural frequencies
symK = sym('K',[N,N]);       % Coupling

symThStoch = sym('thetaStoch',[P,1]);  % Reduced direct variable for RBM  
symPStoch = sym('pStoch',[P,1]);       % Reduced adjoint variable for RBM
symOmStoch = sym('omStoch',[P,1]);     % Reduced natural frequencies for RBM
symKStoch = sym('KStoch',[P,P]);       % Reduced coupling for RBM


syms Vsys;
syms VsysStoch;    
symThth = repmat(symTh,[1,N]);
symThthStoch = repmat(symThStoch,[1,P]);


% Complete model
Vsys = symOm + (symU./N)*sum(symK.*sin(symThth.' - symThth),2);   
% Reduced model for RBM
VsysStoch = symOmStoch + ...
            (symU./P)*sum(symKStoch.*sin(symThthStoch.' - symThthStoch),2);
        

% Jacobians to define the adjoint model through Pontryaghin
jacThStoch = jacobian(VsysStoch,symThStoch);
jacU = jacobian(Vsys,symU);


% Functional
symPsi = 0.5*norm(sin(symThth.' - symThth),'fro');   
symL = 0.5*beta*(symU.'*symU)';   
symJ = symPsi + symL;
symJFcn = matlabFunction(symJ,'Vars',{symTh,symU});


% Numerical values of Omega and K
sigmaOm = 0.1;
OmNum = 0.2*normrnd(0,sigmaOm,N,1);
OmNum = OmNum - mean(OmNum);
KL = abs(max(OmNum)-min(OmNum)) + 1;
KNum = KL*ones(N,N);  
KNumStoch = KL*ones(P,P);

jacU = subs(jacU,symK,KNum);
jacThStoch = subs(jacThStoch,symKStoch,KNumStoch);

% Adjoint model
VsysPStoch = -jacThStoch.'*symPStoch;
% Functional gradient
gradJ = jacU.'*symP;
gradJFcn = matlabFunction(gradJ,'Vars',{symTh,symP});

% Function handle for the reduced model (direct and adjoint)
symFStoch = subs(VsysStoch,symKStoch,KNumStoch);
symFStochFcn = matlabFunction(symFStoch,'Vars',{symThStoch,symOmStoch,symU});
symFadjStoch = subs(VsysPStoch,symKStoch,KNumStoch);
symFadjStochFcn = matlabFunction(symFadjStoch,'Vars',{symThStoch,symPStoch,symU});
                
%% Gradient Descent

error = 10;
iter = 0;
p0vec = zeros(P,1);
p0 = 0;
tcost = zeros(1,maxiter);

while (error > tol && iter < maxiter)
    tic
    iter = iter + 1;
    
    % Resolution of the direct dynamics
    thetaOut = zeros(Nt,N);
    thetaOut(1,:) = theta0;
    for m = 1:Nt-1
        r = randperm(N);
        for k = 1:n
            j = r(P*(k-1)+1:P*(k-1)+P);
            OmNumStoch = OmNum(j);
            thetaFunStoch = @(theta,omega,u) symFStochFcn(theta,omega,u);
            thetaOut(m+1,j) = thetaOut(m,j) + dt*thetaFunStoch(thetaOut(m,j)',OmNumStoch,u(m))';
        end
    end
    
    % Initial datum for the adjoint system
    thetaT = thetaOut(end,:);
    for i = 1:N
        p0vec(i) = p0;
        for j = 1:N
            if j~=i
                p0vec(i) = p0vec(i) + 0.5*sin(2*thetaT(i)-2*thetaT(j));
            end
        end
    end
    
    % Resolution of the adjoint dynamics
    pOut = zeros(Nt,N);
    pOut(end,:) = p0vec;
    
    for m = Nt-1:-1:1
        r = randperm(N);
        for k = 1:n
            j = r(P*(k-1)+1:P*(k-1)+P);
            pFunStoch = @(theta,p,u) symFadjStochFcn(theta,p,u);
            pOut(m,j) = pOut(m+1,j) - dt*pFunStoch(thetaOut(m+1,j)',pOut(m+1,j)',u(m+1))';
        end
    end
    
    Du = gradJFcn(thetaOut',pOut')';
    
    Du = beta*u + Du;
    uOld = u;
    u = u - eta*Du;
    
    DU2 = norm(Du);
    U2 = norm(u);
    Ua2 = norm(uOld-u);
    
    error = DU2/U2;
   
    tcost(iter) = toc;
    
    fprintf("Iteration %i - Error %g - Cost %g\n", iter,error,J);
end

Tcost = sum(tcost);

%% Resolution of the controlled dynamics

symF = subs(Vsys,[symOm,symK],[OmNum,KNum]);
symF = vpa(symF,2);
symFFcn = matlabFunction(symF,'Vars',{t,symTh,symU});

thetaFunOpt = @(t,theta) symFFcn(t,theta,interp1(tspan,u',t));
thetaFunFree = @(t,theta) symFFcn(t,theta,0*interp1(tspan,u',t));
[~,thetaOutOpt] = ode45(thetaFunOpt,tspan,theta0);
[~,thetaOutFree] = ode45(thetaFunFree,tspan,theta0);

%% Plots

close all

figure(1)  % Controlled dynamics
for j = 1:N
    plot(thetaOutOpt(:,j),'LineWidth',1.5)
    hold on
    xlim([1 Nt])
    xticks([1 34 67 100])
    xticklabels({'0','1','2','3'})
    yticks([])
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',16)
    xlabel('Time (s)')
    ylabel('Oscillators')    
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])

%%

figure(2)  % Free dynamics
for j = 1:N
    plot(thetaOutFree(:,j),'LineWidth',2)
    hold on
    xlim([1 Nt])
    xticks([1 34 67 100])
    xticklabels({'0','1','2','3'})
    yticks([])
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',16)
    xlabel('Time (s)')
    ylabel('Oscillators')    
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])

%%

figure(3)  % Control 
plot(u,'LineWidth',2)
xlim([1 100])
xticks([1 34 67 100])
xticklabels({'0','1','2','3'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',16)
xlabel('Time (s)')
Leg = legend('Control');
Leg.Location = 'northwest';

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])