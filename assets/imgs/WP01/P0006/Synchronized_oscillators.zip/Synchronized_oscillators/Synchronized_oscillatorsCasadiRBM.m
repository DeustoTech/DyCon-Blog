%%=========================================================================
%
% GD-RBM algorithm for the synchronization of coupled oscillators using
% Casadi
%
% Author: Umberto Biccari
% Date: 03/06/2020
%
%%=========================================================================

clear all
clc

%% Input data

n = 2;                         % Number of batches
P = 5;                         % Size of each batch
N = n*P;                       % Total number of oscillators

T0 = 0; T = 3;                 % Time interval
Nt = 100;
tspan = linspace(T0,T,Nt);
dt = tspan(2)-tspan(1);

theta0vec = linspace(0,pi,N);  % Initial datum
theta0 = normpdf(theta0vec);
maxiter = 6000;                % Maximum number of iterations allowed
beta = 1e-7;                   % Penalization parameter in the functional
tol = 1e-4;                    % Tolerance
eta = 10;                      % Lenghstep for GD
u = ones(Nt,1);                % Initial control

% Numerical values of Omega and K
sigmaOm = 0.1;
OmNum = 0.2*normrnd(0,sigmaOm,N,1);
OmNum = OmNum - mean(OmNum);
KL = abs(max(OmNum)-min(OmNum)) + 1;
KNum = KL*ones(N,N);  
KNumStoch = KL*ones(P,P);

%% Construction of the symbolic model

import casadi.*

tic

t = SX.sym('t');                 % Time variable
symTh = SX.sym('theta',[N,1]);   % Direct variable
symP = SX.sym('p',[N,1]);        % Adjoint variable
symOm = SX.sym('om',[N,1]);      % Natural frequencies 
symK  = SX.sym('K',[N,N]);       % Coupling 
symU  = SX.sym('u',[1,1]);       % Control

symThStoch = SX.sym('thetaStoch',[P,1]); % Reduced direct variable for RBM  
symPStoch = SX.sym('pStoch',[P,1]);      % Reduced adjoint variable for RBM
symOmStoch = SX.sym('omStoch',[P,1]);    % Reduced natural frequencies for RBM
symKStoch = SX.sym('KStoch',[P,P]);      % Reduced coupling for RBM

syms Vsys;       % Vector field
syms VsysStoch;  % Reduced vector field for RBM

% Kuramoto interaction terms
 
Vsys = casadi.Function('Vsys',{symOm,symK,symTh,symU},...
       {symOm + (symU./N)*sum(symK.*sin(repmat(symTh,[1 N]).'...
        - repmat(symTh,[1 N])),2)});   
    
% Reduced model for RBM

VsysStoch = casadi.Function('VsysStoch',{symOmStoch,symKStoch,symThStoch,symU},...
            {symOmStoch + (symU./P)*sum(symKStoch.*sin(repmat(symThStoch,[1 P]).' ...
            - repmat(symThStoch,[1 P])),2)});   

rng('default');
rng(1,'twister');

symF = casadi.Function('symF',{symTh,symU},{Vsys(OmNum,KNum,symTh,symU)});       
symFStoch = casadi.Function('symFStoch',{symOmStoch,symThStoch,symU},...
         {VsysStoch(symOmStoch,KNumStoch,symThStoch,symU)});

jacU = jacobian(symF(symTh,symU),symU);   
jacThStoch = jacobian(symFStoch(symOmStoch,symThStoch,symU),symThStoch);

% Adjoint model
symFadjoint = casadi.Function('symFadjoint',{symThStoch,symPStoch,symU},{-jacThStoch.'*symPStoch});       
% Functional gradient
gradJ = casadi.Function('gradJ',{symTh,symP},{jacU.'*symP});

Tcost0 = toc;
                
%% Gradient Descent

error = 10;
iter = 0;
p0vec = zeros(P,1);
p0 = 0;
tcost = zeros(1,maxiter);

while (error > tol && iter < maxiter)
    tic
    iter = iter + 1;
    
    % Resolution of the direct dynamics
    thetaOut = zeros(Nt,N);
    thetaOut(1,:) = theta0;
    for m = 1:Nt-1
        r = randperm(N);
        for k = 1:n
            j = r(P*(k-1)+1:P*(k-1)+P);
            OmNumStoch = OmNum(j);
            thetaOut(m+1,j) = thetaOut(m,j) + dt*full(symFStoch(OmNumStoch,thetaOut(m,j)',u(m)))';
        end
    end
    
    % Initial datum for the adjoint system
    thetaT = thetaOut(end,:);
    for i = 1:N
        p0vec(i) = p0;
        for j = 1:N
            if j~=i
                p0vec(i) = p0vec(i) + 0.5*sin(2*thetaT(i)-2*thetaT(j));
            end
        end
    end
    
    % Resolution of the adjoint dynamics
    pOut = zeros(Nt,N);
    pOut(end,:) = p0vec;
    
    for m = Nt-1:-1:1
        r = randperm(N);
        for k = 1:n
            j = r(P*(k-1)+1:P*(k-1)+P);
            pOut(m,j) = pOut(m+1,j) - dt*full(symFadjoint(thetaOut(m+1,j)',pOut(m+1,j)',u(m+1)))';
        end
    end
    
    Du = full(gradJ(thetaOut',pOut'))';
    
    Du = beta*u + Du;
    uOld = u;
    u = u - eta*Du;
    
    DU2 = norm(Du);
    U2 = norm(u);
    Ua2 = norm(uOld-u);
    
    errorOld = error;
    error = DU2/U2;
   
    tcost(iter) = toc;
    
    fprintf("Iteration %i - Error %g\n", iter,error);
end

Tcost = Tcost0 + sum(tcost);

%% Resolution of the controlled dynamics

thetaOutControlled = zeros(Nt,N);
thetaOutFree = zeros(Nt,N);
thetaOutControlled(1,:) = theta0;
thetaOutFree(1,:) = theta0;

for m = 1:Nt-1
    thetaOutControlled(m+1,:) = thetaOutControlled(m,:) + dt*full(symF(thetaOutControlled(m,:)',u(m)))';
    thetaOutFree(m+1,:) = thetaOutFree(m,:) + dt*full(symF(thetaOutFree(m,:)',1))';
end

%% Plots

close all


figure(1)  % Controlled dynamics
for j = 1:N
    plot(thetaOutControlled(:,j),'LineWidth',1.5)
    hold on
    xlim([1 Nt])
    xticks([1 34 67 100])
    xticklabels({'0','1','2','3'})
    yticks([0 0.2 0.4])
    yticklabels({'-0.5','0','0.5'})
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',16)
    xlabel('Time (s)')
    ylabel('oscillators \theta_i')    
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])

%%

figure(2)  % Free dynamics
for j = 1:N
    plot(thetaOutFree(:,j),'LineWidth',1.5)
    hold on
    xlim([1 Nt])
    xticks([1 34 67 100])
    xticklabels({'0','1','2','3'})
    %yticks([])
    a = get(gca,'XTickLabel');
    set(gca,'XTickLabel',a,'fontsize',16)
    xlabel('Time (s)')
    ylabel('Oscillators \theta_i')    
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])

%%

figure(3)  % Control 
plot(u,'LineWidth',2)
xlim([1 100])
xticks([1 34 67 100])
xticklabels({'0','1','2','3'})
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',16)
xlabel('Time (s)')
Leg = legend('Control');
Leg.Location = 'northwest';

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 0.4, 0.4])