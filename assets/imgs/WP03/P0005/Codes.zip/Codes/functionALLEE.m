function f=functionALLEE(t,y)
theta=0.5;
f=[y(2);-y(1)*(1-y(1))*(y(1)-theta)];
end