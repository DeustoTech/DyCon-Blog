function f=functionKPP2(t,y)
f=[-y(2);+y(1)*(1-y(1))];
end