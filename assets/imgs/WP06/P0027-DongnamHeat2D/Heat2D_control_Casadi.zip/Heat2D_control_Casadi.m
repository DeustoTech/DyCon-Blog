%% Optimal Control Problem with CasADi on null-controllability of the network system.
% This code needs the installation of CasADi 3.4.5:
% https://web.casadi.org/get/
%%
% In this post, we will consider the null-controllability in the finite 
% difference scheme of the 2D Heat equation. As a modification to the 
% optimal control problem, we use CasADi and IpOpt to simulate optimization.
%%
% A similar problem has been treated in the DyCon Blog post,
% https://deustotech.github.io/DyCon-Blog/tutorial/wp03/WP03-P0022
% which deals with the one-dimensional fractional heat equation under
% positivity constraints.
%%
% We start with the finite difference scheme of the 2D Heat equation and
% the control on one boundary of the square domain $[0,1]^2$.
% $$
% \begin{cases}
% \frac{dz_{i,j}}{dt} = (N+1)^2(z_{i+1,j}+z_{i-1,j}+z_{i,j+1}+z_{i,j-1}-4z_{i,j}) + u\delta(i-1), & i,j = 1,\ldots,N,~ t \in (0,T)
% \\
% z_{i,j}(t) = 0, & i = 0, N+1, ~\text{or}~ j=0, N+1,~ t \in (0,T)
% \\
% z_{i,j}(0)=z^0_{i,j}, & i,j=1,\ldots,N.
% \end{cases}
% $$
%%
% We will consider the problem of steering the initial datum:
% $$
% z^0_{i,j} = \begin{cases} (-1)^{i+1} & \text{if}~ i+j=N+1,\\ 0 & \text{otherwise}. \end{cases}
% $$
%%
% to the zero solution. This is a well-known controllable problem.

%% Problem formulation
% Parameters for the problem
N_size = 4; % Space discretization for 1D
Nx = N_size^2; % Space discretization for 2D
Nt = 20; % Time discretization : need to check the CFL condition
T = 0.1; % Final time

% Discretization of the Space
xline = linspace(0,1,N_size+2);
xline = xline(2:end-1);
dx = xline(2) - xline(1);
% 
xline_f = linspace(xline(1),xline(end),2*N_size);

[xms,yms]   = meshgrid(xline,xline);
[xmsf,ymsf] = meshgrid(xline_f,xline_f);

% Initial data 
Y0_2d = zeros(N_size);
for i=1:N_size
    for j=1:N_size
        Y0_2d(i,j) = sin(xline(i)*pi)*sin(xline(j)*pi);
    end
end
Y0 = Y0_2d(:);
% Target data
Y1 = 0.3*Y0;

% Definition of the dynamics : Y' = AY+BU
B = zeros(N_size^2,N_size); B(1:N_size,1:N_size) = eye(N_size);

A1_mat = diag(-4*ones(N_size,1),0);
A1_mat = A1_mat + diag(ones(N_size-1,1),1) +diag(ones(N_size-1,1),-1);
A2_mat = A1_mat;
for j=1:N_size-1
    A2_mat = blkdiag(A2_mat,A1_mat);
end
A_mat = A2_mat + diag(ones(N_size.*(N_size-1),1),N_size) + diag(ones(N_size.*(N_size-1),1),-N_size);
A = A_mat; % A: Discrete Laplacian in 2D with uniform squared mesh
%%
clf
options_plot_graphs = {'LineWidth',2,'DisplayName','off','NodeColor','r','ArrowSize',9,'MarkerSize',7,'NodeLabel',{}};
plot(digraph(A),'XData',xms(:)','YData',yms(:)',options_plot_graphs{:})
xlabel('x-axis')
ylabel('y-axis')
grid on
%%

% Discretization of the time : we need to check CFL condition to change 'Nt'.
tline = linspace(0,T,Nt+1); %uniform time mesh

dt = tline(2)-tline(1);

% Simulation of the uncontrolled trajectory
M = eye(Nx) - 0.5*dt/dx.^2*A;
L = eye(Nx) + 0.5*dt/dx.^2*A;
P = 0.5*dt*B;

Y = zeros(Nx,Nt+1);
Y(:,1) = Y0;
for k=1:Nt % loop over time intervals
   % Crank-Nicolson method without control
   Y(:,k+1) = M\L*Y(:,k); 
end
YT = Y(:,Nt+1);

%%
clf
Z = reshape(Y(:,1),N_size,N_size);
Z = interp2(xms,yms,Z,xmsf,ymsf);
isurf = surf(xmsf,ymsf,Z,'FaceAlpha',0.5);
isurf.CData = isurf.CData*0 + 1;
hold on 
Z = reshape(Y(:,end),N_size,N_size);
Z = interp2(xms,yms,Z,xmsf,ymsf);
jsurf = surf(xmsf,ymsf,Z,'FaceAlpha',0.5);
jsurf.CData = jsurf.CData*0 + 10;
%
jsurf.Parent.Color = 'none';
lightangle(10,10)
%
legend({'Initial Condition','Target'})

%% Optimization problem
opti = casadi.Opti();  % CasADi function

% ---- Input variables ---------
X = opti.variable(Nx,Nt+1); % state trajectory
U = opti.variable(N_size,Nt+1);   % control

% ---- Dynamic constraints --------
for k=1:Nt % loop over control intervals
   % Crank-Nicolson method : this helps us to boost the optimization
   opti.subject_to(M*X(:,k+1)== L*X(:,k) + P*(U(:,k)+U(:,k+1)));
end

% ---- State constraints --------
opti.subject_to(X(:,1)==Y0);
opti.subject_to(X(:,Nt+1)==Y1);

% ---- Optimization objective  ----------
Cost = (dx*sum(sum(U.^2))*(T/Nt));
opti.minimize(Cost); % minimizing L2 at the final time

% ---- initial guesses for solver ---
opti.set_initial(X, Y);
opti.set_initial(U, 0);

% ---- solve NLP              ------
p_opts = struct('expand',true);
s_opts = struct('max_iter',10000); % iteration limitation

opti.solver('ipopt',p_opts,s_opts); % set numerical backend
tic
sol = opti.solve();   % actual solve
toc


%% Post-processing
Sol_x = sol.value(X); % solved controlled trajectory
Sol_u = sol.value(U); % solved control
%Sol_x = opti.debug.value(X);
%Sol_u = opti.debug.value(U); % final data if algorithm stops with error

Sol_z = zeros(N_size+2,N_size+2,1); % displaying variable
Sol_z(2:end-1,2:end-1) = reshape(Sol_x(:,end),[N_size,N_size]);
Sol_y = zeros(N_size+2,N_size+2,1); % displaying uncontrolled variable
Sol_y(2:end-1,2:end-1) = reshape(YT,[N_size,N_size]);

xxline = repmat(linspace(0,1,N_size+2),[N_size+2 1]);
yyline = repmat(linspace(0,1,N_size+2)',[1 N_size+2]);
max_y = max(Sol_z(:));

figure
surf(xxline,yyline,Sol_y(:,:));
xlabel('x'); ylabel('y'); zlabel('z'); title('Uncontrolled final values');
zlim([-max_y max_y])
%hold on
figure
%hold on
surf(xxline,yyline,Sol_z(:,:));
zlim([-max_y max_y])
xlabel('x'); ylabel('y'); zlabel('z'); title('Controlled final values');

%%
Final_2 = zeros(N_size+2,N_size+2,Nt+1); % displaying variable
Final_2(2:end-1,2:end-1,:) = reshape(Sol_x(:,:),[N_size,N_size,Nt+1]);

Final_1 = zeros(N_size+2,N_size+2,Nt+1); % displaying variable
Final_1(2:end-1,2:end-1,:) = reshape(Y(:,:),[N_size,N_size,Nt+1]);

% Free dynamics
fig = figure;
isurf = surf(Final_1(:,:,1));
zlim([-1 1])
for it = 1:Nt+1
   isurf.ZData =  Final_1(:,:,it);
%    pause(0.1)
end
% Controlled dynamics
fig = figure;
isurf = surf(Final_2(:,:,1));
zlim([-1 1])
for it = 1:Nt+1
   isurf.ZData =  Final_2(:,:,it);
%    pause(0.1)
end
%%
% The simulation needs careful regularization coefficients, 1e5 which is
% big enough, in the cost function. This is from the nature of the
% Laplacian, which has significantlly different eigenvalues and high
% control cost for small time horizon.
%%
% Next, we consider a small modification of the dynamics 'A_mat', which makes the
% dynamics controllable by only one node (1,1). This is impossible in the
% current operator since the initial data 'Y0' is not controllable.
%%
% The following matrix 'AS_mat' links the nodes in a line, for example,
% 1-2-3-6-5-4-7-8-9 for $N=3$, which is a partial network of 'A_mat'. Since
% the 1D heat equation is controllable, 'AS_mat' is controllable by the
% first node: 

AC_mat = diag(ones(N_size-1,1),-1);
for j=1:2:N_size-2
    AC_mat = blkdiag(AC_mat,diag(ones(N_size-1,1),1));
    AC_mat(end,end-N_size)=1;
    if N_size==2
        break
    end
    AC_mat = blkdiag(AC_mat,diag(ones(N_size-1,1),-1));
    AC_mat(end-N_size+1,end-2*N_size+1)=1;
end
if length(AC_mat) < (N_size.^2)
    AC_mat = blkdiag(AC_mat,diag(ones(N_size-1,1),1));
    AC_mat(end,end-N_size)=1;
end

AS_mat = (AC_mat + AC_mat') - 2*eye(Nx);
%%
options_plot_graphs = {'LineWidth',2,'DisplayName','off','NodeColor','r','ArrowSize',9,'MarkerSize',7,'NodeLabel',{}};
plot(digraph(AS_mat),'XData',xms(:)','YData',yms(:)',options_plot_graphs{:})
xlabel('x-axis');ylabel('y-axis')
title('Network')
grid on
%%
% Note that 'AS_mat' has the nonzero elements in the positions that 'A_mat'
% has. By deleting several interactions of 'A_mat', 'AS_mat' is now exactly
% controllable by one node. This is the idea of the structural
% controllability in the network system, called 'network control'.

B = zeros(N_size^2,1); B(1) = 1;
A = N_size.^2*AS_mat;
% Y' = AY + BU

T = 0.1;
Nt = 30;
tline = linspace(0,T,Nt+1); %uniform time mesh
dt = tline(2)-tline(1);

% Simulation of the uncontrolled trajectory
M = eye(Nx) - 0.5*dt/dx.^2*A;
L = eye(Nx) + 0.5*dt/dx.^2*A;
P = 0.5*dt*B;

Y = zeros(Nx,Nt+1);
Y(:,1) = Y0;
for k=1:Nt % loop over time intervals
   % Crank-Nicolson method without control
   Y(:,k+1) = M\L*Y(:,k); 
end
YT = Y(:,Nt+1);
Y1 = 1.5*YT;
% surf(Y)
% plot(YT)

%% Optimization problem
opti = casadi.Opti();  % CasADi function

% ---- Input variables ---------
X = opti.variable(Nx,Nt+1); % state trajectory
U = opti.variable(1,Nt+1);   % control

% ---- Dynamic constraints --------
for k=1:Nt % loop over control intervals
   % Crank-Nicolson method 
   opti.subject_to(M*X(:,k+1)== L*X(:,k) + P*(U(:,k)+U(:,k+1)));
end

% ---- State constraints --------
opti.subject_to(X(:,1)==Y0);
opti.subject_to(X(:,Nt+1)==Y1);

% ---- Optimization objective  ----------
Cost = (sum(U.^2)*(T/Nt)); %1e3*dx^2*sum(sum((X(:,Nt+1)-Y1).^2))+;
opti.minimize(Cost); % minimizing L2 at the final time

% ---- Initial guess ----
opti.set_initial(X, Y);
opti.set_initial(U, 0);

% ---- solve NLP              ------
p_opts = struct('expand',true);
s_opts = struct('max_iter',1e5); % cut down the algorithm at the 1000-th iteration.
opti.solver('ipopt',p_opts,s_opts); % set numerical backend
tic
sol = opti.solve();   % actual solve
toc
%% Post-processing
%Sol_x = sol.value(X); % solved controlled trajectory
%Sol_u = sol.value(U); % solved control
Sol_x = opti.debug.value(X);
Sol_u = opti.debug.value(U); % final data if algorithm stops with error

Sol_z = zeros(N_size+2,N_size+2,1); % displaying variable
Sol_z(2:end-1,2:end-1) = reshape(Sol_x(:,end),[N_size,N_size]);
Sol_y = zeros(N_size+2,N_size+2,1); % displaying uncontrolled variable
Sol_y(2:end-1,2:end-1) = reshape(YT,[N_size,N_size]);

xxline = repmat(linspace(0,1,N_size+2),[N_size+2 1]);
yyline = repmat(linspace(0,1,N_size+2)',[1 N_size+2]);
max_y = max(abs(Sol_z(:)));

figure(1)
surf(xxline,yyline,Sol_y(:,:));
xlabel('x'); ylabel('y'); zlabel('z'); title('Uncontrolled final values');
zlim([-max_y max_y])
%hold on
figure(2)
%hold on
surf(xxline,yyline,Sol_z(:,:));
zlim([-max_y max_y])
xlabel('x'); ylabel('y'); zlabel('z'); title('Controlled final values');

%% Recover the trajectories
% The algorithm of IpOpt does not guarantee the dynamics exactly follows
% the discrete time-evolution, but approximate it. We may use the
% linear solver in Matlab to recover the exact dynamics with the implicit
% C-N method. This process is needed if we stop the algorithm and test that
% it is an approximate solution.

Yc = zeros(Nx,Nt+1);
Yc(:,1) = Y0;
for k=1:Nt % loop over control intervals
   % Crank-Nicolson method
   Yc(:,k+1) = M\L*Yc(:,k) + M\P*(Sol_u(k)+Sol_u(k+1)); 
   % M Y(:,k+1) = L Y(:,k) + P (u(k)+u(k+1)); 
end
YTc = Yc(:,Nt+1);
figure
plot(YT,'-')
hold on
plot(Sol_x(:,end),'r*')
plot(YTc,'b*')

% Save the data
Final_3 = zeros(N_size+2,N_size+2,Nt+1); % displaying variable
Final_3(2:end-1,2:end-1,:) = reshape(Y(:,:),[N_size,N_size,Nt+1]);

Final_4 = zeros(N_size+2,N_size+2,Nt+1); % displaying variable
Final_4(2:end-1,2:end-1,:) = reshape(Yc(:,:),[N_size,N_size,Nt+1]);

% Free dynamics
fig = figure;
isurf = surf(Final_3(:,:,1));
zlim([-2 2])
for it = 1:Nt+1
   isurf.ZData =  Final_3(:,:,it);
   pause(0.1)
end
% Controlled dynamics
fig = figure;
isurf = surf(Final_4(:,:,1));
zlim([-2 2])
for it = 1:Nt+1
   isurf.ZData =  Final_4(:,:,it);
   pause(0.1)
end


%%
% Sure, this problem needs a big control cost (or long time horizon) and
% also more calculation costs for optimization since its close
% approximation 'A_mat' was not controllable.